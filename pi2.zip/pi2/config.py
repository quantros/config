# Версия софта от 13:30 27.08.2025
LICENSE_KEY = 'AAFT7YcmaMp0JtmVxPYhTkiLM37dTqIN9iOhx9VRQVq7H-4QyvZXM1K6'  # Брать ключ в боте, по кнопке "Софты"

MOBILE_PROXY = False  # True - мобильные proxy/False - обычные proxy
ROTATE_IP = False  # Настройка только для мобильных proxy

TG_BOT_TOKEN = '8411928563:AAEBRk67DaaZDzzyqmrcCzRLov-ZwcJ5eWc'  # str ('2282282282:NTcwMzA0Mjg1NC-vVxT3nb-jr-db976M435xmT_0R7tnaQSVBM6Xdjry')
TG_USER_ID = 123  # int (22822822) or None

SHUFFLE_WALLETS = False
PAUSE_BETWEEN_WALLETS = [1, 1]
PAUSE_BETWEEN_MODULES = [1, 1]
MAX_PARALLEL_ACCOUNTS = 5

RETRIES = 3  # Сколько раз повторять 'зафейленное' действие
PAUSE_BETWEEN_RETRIES = 10  # Пауза между повторами

COMPLETE_QUESTS = False
PLAY_GAME = False  # Настройка в GameSettings


class GameSettings:
    num_plays = [2, 4]
