import asyncio
import re
import ssl
from datetime import datetime, timezone, timedelta
from imaplib import IMAP4_SSL
from typing import Optional
from urllib.parse import urlparse

from loguru import logger
from imap_tools import MailBox

from src.utils.proxy_manager import Proxy


class MailBoxClient(MailBox):
    def __init__(
            self,
            host: str,
            *,
            proxy: Proxy | None,
            port: int = 993,
            timeout: float = None,
            ssl_context=None,
    ):
        self._proxy = proxy
        super().__init__(host=host, port=port, timeout=timeout, ssl_context=ssl_context)
        if self._proxy:
            self.parsed_proxy = self._parse_proxy(self._proxy.proxy_url)

    @staticmethod
    def _parse_proxy(proxy_url: str) -> dict:
        parsed = urlparse(proxy_url)
        return {
            'scheme': parsed.scheme,
            'host': parsed.hostname,
            'port': parsed.port,
            'username': parsed.username,
            'password': parsed.password,
        }

    def _get_mailbox_client(self):
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS)
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

        if self._proxy:
            proxy = self.parsed_proxy

            return IMAP4_SSL(
                proxy['host'],
                port=proxy['port'],
                timeout=self._timeout,
                ssl_context=ssl_context,
            )
        else:
            return IMAP4_SSL(
                self._host,
                port=self._port,
                timeout=self._timeout,
                ssl_context=ssl_context,
            )


class AsyncEmailChecker:
    def __init__(self, email: str, password: str):
        self.email = email
        self.password = password
        self.imap_server = self._get_imap_server(email)
        self.search_start_time = datetime.now(timezone.utc)

    def _get_imap_server(self, email: str) -> str:
        if email.endswith("@rambler.ru"):
            return "imap.rambler.ru"
        elif email.endswith("@gmail.com"):
            return "imap.gmail.com"
        elif "@gmx." in email:
            return "imap.gmx.com"
        elif "outlook" in email:
            return "imap-mail.outlook.com"
        elif email.endswith("@mail.ru"):
            return "imap.mail.ru"
        else:
            return "imap.firstmail.ltd"

    def _search_for_pattern(
            self, mailbox: MailBox, pattern: str | re.Pattern, is_regex: bool = True
    ) -> Optional[str]:
        time_threshold = self.search_start_time - timedelta(seconds=600)

        messages = sorted(
            mailbox.fetch(),
            key=lambda x: (x.date.replace(tzinfo=timezone.utc) if x.date.tzinfo is None else x.date),
            reverse=True,
        )
        rx = re.compile(pattern) if is_regex and isinstance(pattern, str) else pattern

        for msg in messages:
            msg_date = msg.date.replace(tzinfo=timezone.utc) if msg.date.tzinfo is None else msg.date
            if msg_date < time_threshold:
                continue

            subject = msg.subject or ""
            text = msg.text or ""
            html = msg.html or ""

            if is_regex:
                if rx:
                    m = rx.search(subject)
                    if m:
                        return m.group(0)
                    m = rx.search(text)
                    if m:
                        return m.group(0)
                    m = rx.search(html)
                    if m:
                        return m.group(0)
            else:
                if pattern in subject or pattern in text or pattern in html:
                    return pattern

        return None

    def _search_for_pattern_in_spam(
            self,
            mailbox: MailBox,
            spam_folder: str,
            pattern: str | re.Pattern,
            is_regex: bool = True,
    ) -> Optional[str]:
        if mailbox.folder.exists(spam_folder):
            mailbox.folder.set(spam_folder)
            return self._search_for_pattern(mailbox, pattern, is_regex)
        return None

    async def check_email_for_verification_link(
            self,
            pattern: str | re.Pattern,
            is_regex: bool = True,
            max_attempts: int = 20,
            delay_seconds: int = 3,
            proxy: Optional[Proxy] = None,
    ) -> Optional[str]:
        try:
            for attempt in range(max_attempts):
                def search_inbox():
                    with MailBoxClient(self.imap_server, proxy=proxy, timeout=30).login(
                            self.email, self.password
                    ) as mailbox:
                        return self._search_for_pattern(mailbox, pattern, is_regex)

                result = await asyncio.to_thread(search_inbox)
                if result:
                    return result
                if attempt < max_attempts - 1:
                    await asyncio.sleep(delay_seconds)

            logger.warning(
                f"Account: {self.email} | Pattern not found after {max_attempts} attempts, searching in spam folder..."
            )
            spam_folders = ("SPAM", "Spam", "spam", "Junk", "junk", "Spamverdacht")

            def search_spam():
                with MailBoxClient(self.imap_server, proxy=proxy, timeout=30).login(
                        self.email, self.password
                ) as mailbox:
                    for spam_folder in spam_folders:
                        result = self._search_for_pattern_in_spam(
                            mailbox, spam_folder, pattern, is_regex
                        )
                        if result:
                            logger.success(
                                f"Account: {self.email} | Found pattern in spam"
                            )
                            return result
                return None

            result = await asyncio.to_thread(search_spam)
            if result:
                return result

            logger.error(f"Account: {self.email} | Pattern not found in any folder")
            return None

        except Exception as error:
            logger.error(
                f"Account: {self.email} | Failed to check email for pattern: {error}"
            )
            return None
