from src.utils.runner import *

module_handlers = {
    'COMPLETE_QUESTS': process_quests,
    'PLAY_GAME': process_play_game
}
