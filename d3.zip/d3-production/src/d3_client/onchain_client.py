import random
import time
from typing import Optional

from curl_cffi.requests import AsyncSession
from eth_account.messages import encode_typed_data
from eth_typing import HexStr
from loguru import logger
from eth_abi import encode

from config import RETRIES, PAUSE_BETWEEN_RETRIES
from src.d3_client.types import DomainItem
from src.models.contracts import DomainData, GalxeData
from src.utils.common.wrappers.decorators import retry
from src.utils.data.chains import DOMA
from src.utils.proxy_manager import Proxy
from src.utils.user.account import Account


class OnchainClient(Account):
    def __init__(
            self,
            private_key: str,
            proxy: Proxy,
            session: AsyncSession,
            rpc: Optional[str] = None
    ):
        super().__init__(private_key=private_key, proxy=proxy, rpc=rpc or DOMA.rpc)
        self.session = session

    async def call_approve(self, amount: int, from_token_address: str, spender: str):
        await self.approve_token(
            amount=amount,
            private_key=self.private_key,
            from_token_address=from_token_address,
            spender=spender,
            address_wallet=self.wallet_address,
            web3=self.web3
        )

    async def claim_domain(self, tx_data: dict, domain_info: dict) -> Optional[HexStr]:
        token_id = int(domain_info['data']['name']['tokens'][0]['tokenId'])
        data = '0xbce69e8c' + encode(
            ['bytes32', 'uint256', 'bytes32', 'uint256', 'bytes32', 'uint256', 'bytes'],
            [
                self.web3.to_bytes(primitive=token_id),
                0,
                self.web3.to_bytes(
                    primitive=int(
                        tx_data['uploadVerifiedRegistrantContacts']['proofOfContactsVoucher']['registrantHandle']
                    )
                ),
                tx_data['uploadVerifiedRegistrantContacts']['proofOfContactsVoucher']['proofSource'],
                self.web3.to_bytes(
                    hexstr=tx_data['uploadVerifiedRegistrantContacts']['proofOfContactsVoucher']['nonce']
                ),
                tx_data['uploadVerifiedRegistrantContacts']['proofOfContactsVoucher']['expiresAt'],
                self.web3.to_bytes(hexstr=tx_data['uploadVerifiedRegistrantContacts']['signature'])
            ]
        ).hex()

        confirmed = False
        tx_hash = None
        try:
            tx = {
                'chainId': await self.web3.eth.chain_id,
                'from': self.wallet_address,
                'to': self.web3.to_checksum_address(DomainData.claim_address),
                'nonce': await self.web3.eth.get_transaction_count(self.wallet_address),
                'gasPrice': await self.web3.eth.gas_price,
                'data': data,
                'value': 0
            }
            gas_limit = await self.web3.eth.estimate_gas(tx)
            tx.update({'gas': gas_limit})

            tx_hash = await self.sign_transaction(tx)
            confirmed = await self.wait_until_tx_finished(tx_hash)

        except Exception as ex:
            logger.error(f'Something went wrong {ex}')

        if confirmed and tx_hash:
            return tx_hash

    async def buy_domain(self, tx_data: dict, price: int) -> Optional[HexStr]:
        contract = self.load_contract(
            address=DomainData.address,
            abi=DomainData.abi,
            web3=self.web3
        )

        order = tx_data['order']
        parameters = order['parameters']
        signature = order['signature']
        extra_data = tx_data['extraData']

        offer = [
            (
                o['itemType'],
                self.web3.to_checksum_address(o['token']),
                int(o['identifierOrCriteria']),
                int(o['startAmount']),
                int(o['endAmount'])
            )
            for o in parameters['offer']
        ]

        consideration = [
            (
                c['itemType'],
                self.web3.to_checksum_address(c['token']),
                int(c['identifierOrCriteria']),
                int(c['startAmount']),
                int(c['endAmount']),
                self.web3.to_checksum_address(c['recipient'])
            )
            for c in parameters['consideration']
        ]

        order_parameters = (
            self.web3.to_checksum_address(parameters['offerer']),
            self.web3.to_checksum_address(parameters['zone']),
            offer,
            consideration,
            parameters['orderType'],
            int(parameters['startTime']),
            int(parameters['endTime']),
            self.web3.to_bytes(hexstr=parameters['zoneHash']),
            int(parameters['salt'], 16),
            self.web3.to_bytes(hexstr=parameters['conduitKey']),
            int(parameters['totalOriginalConsiderationItems'])
        )

        advanced_order = (
            order_parameters,
            1,
            1,
            self.web3.to_bytes(hexstr=signature),
            self.web3.to_bytes(hexstr=extra_data)
        )

        criteria_resolvers = []

        fulfiller_conduit_key = b'\x00' * 32
        recipient = '0x0000000000000000000000000000000000000000'

        confirmed = False
        tx_hash = None
        try:
            tx = await contract.functions.fulfillAdvancedOrder(
                advanced_order,
                criteria_resolvers,
                fulfiller_conduit_key,
                recipient
            ).build_transaction({
                'value': price,
                'nonce': await self.web3.eth.get_transaction_count(self.wallet_address),
                'from': self.wallet_address,
                'gasPrice': await self.web3.eth.gas_price
            })
            tx_hash = await self.sign_transaction(tx)
            confirmed = await self.wait_until_tx_finished(tx_hash)
        except Exception as ex:
            logger.error(f'Something went wrong {ex}')

        if confirmed and tx_hash:
            return tx_hash

    async def get_listing_signature(self, domain_data: dict, price: int):
        token_address = domain_data['data']['name']['tokens'][0]['tokenAddress']
        token_id = domain_data['data']['name']['tokens'][0]['tokenId']

        start_time = int(time.time())
        end_time = int(start_time + 60 * 60 * 24 * 90)
        salt = str(random.randint(1, 2 ** 256 - 1))

        fee1_bps = 50
        fee2_bps = 250

        fee1_recipient = "0x2e7cc63800e77bb8c662c45ef33d1ccc23861532"
        fee2_recipient = "0x5318579e61a7a6cd71a8fd163c1a6794b2695e2b"

        fee1_amount = price * fee1_bps // 10_000
        fee2_amount = price * fee2_bps // 10_000
        seller_amount = price - fee1_amount - fee2_amount

        consideration = [
            {
                "itemType": 0,
                "token": "0x0000000000000000000000000000000000000000",
                "identifierOrCriteria": "0",
                "startAmount": str(seller_amount),
                "endAmount": str(seller_amount),
                "recipient": self.wallet_address
            },
            {
                "itemType": 0,
                "token": "0x0000000000000000000000000000000000000000",
                "identifierOrCriteria": "0",
                "startAmount": str(fee1_amount),
                "endAmount": str(fee1_amount),
                "recipient": self.web3.to_checksum_address(fee1_recipient)
            },
            {
                "itemType": 0,
                "token": "0x0000000000000000000000000000000000000000",
                "identifierOrCriteria": "0",
                "startAmount": str(fee2_amount),
                "endAmount": str(fee2_amount),
                "recipient": self.web3.to_checksum_address(fee2_recipient)
            }
        ]

        data = {
            "types": {
                "OrderComponents": [
                    {"name": "offerer", "type": "address"},
                    {"name": "zone", "type": "address"},
                    {"name": "offer", "type": "OfferItem[]"},
                    {"name": "consideration", "type": "ConsiderationItem[]"},
                    {"name": "orderType", "type": "uint8"},
                    {"name": "startTime", "type": "uint256"},
                    {"name": "endTime", "type": "uint256"},
                    {"name": "zoneHash", "type": "bytes32"},
                    {"name": "salt", "type": "uint256"},
                    {"name": "conduitKey", "type": "bytes32"},
                    {"name": "counter", "type": "uint256"}
                ],
                "OfferItem": [
                    {"name": "itemType", "type": "uint8"},
                    {"name": "token", "type": "address"},
                    {"name": "identifierOrCriteria", "type": "uint256"},
                    {"name": "startAmount", "type": "uint256"},
                    {"name": "endAmount", "type": "uint256"}
                ],
                "ConsiderationItem": [
                    {"name": "itemType", "type": "uint8"},
                    {"name": "token", "type": "address"},
                    {"name": "identifierOrCriteria", "type": "uint256"},
                    {"name": "startAmount", "type": "uint256"},
                    {"name": "endAmount", "type": "uint256"},
                    {"name": "recipient", "type": "address"}
                ],
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                    {"name": "verifyingContract", "type": "address"}
                ]
            },
            "domain": {
                "name": "Seaport",
                "version": "1.6",
                "chainId": "0x17cc4",
                "verifyingContract": "0x0000000000000068f116a894984e2db1123eb395"
            },
            "primaryType": "OrderComponents",
            "message": {
                "offerer": self.wallet_address,
                "zone": self.web3.to_checksum_address("0xcef2071b4246db4d0e076a377348339f31a07dea"),
                "offer": [
                    {
                        "itemType": 2,
                        "token": self.web3.to_checksum_address(token_address),
                        "identifierOrCriteria": token_id,
                        "startAmount": "1",
                        "endAmount": "1"
                    }
                ],
                "consideration": consideration,
                "orderType": 2,
                "startTime": str(start_time),
                "endTime": str(end_time),
                "zoneHash": "0x0000000000000000000000000000000000000000000000000000000000000000",
                "salt": salt,
                "conduitKey": "0x0000000000000000000000000000000000000000000000000000000000000000",
                "counter": "0"
            }
        }

        structured_msg = encode_typed_data(full_message=data)
        signed_data = self.account.sign_message(structured_msg)
        signature = signed_data.signature.hex()
        return '0x' + signature, data['message']

    async def get_offer_signature(self, domain: DomainItem, amount: int):
        start_time = int(time.time())
        end_time = int(start_time + 60 * 60 * 24)
        salt = str(random.randint(1, 2 ** 256 - 1))

        fee1_bps = 50
        fee2_bps = 250

        fee1_recipient = "0x2e7cc63800e77bb8c662c45ef33d1ccc23861532"
        fee2_recipient = "0x5318579e61a7a6cd71a8fd163c1a6794b2695e2b"

        fee1_amount = amount * fee1_bps // 10_000
        fee2_amount = amount * fee2_bps // 10_000

        data = {
            "types": {
                "OrderComponents": [
                    {"name": "offerer", "type": "address"},
                    {"name": "zone", "type": "address"},
                    {"name": "offer", "type": "OfferItem[]"},
                    {"name": "consideration", "type": "ConsiderationItem[]"},
                    {"name": "orderType", "type": "uint8"},
                    {"name": "startTime", "type": "uint256"},
                    {"name": "endTime", "type": "uint256"},
                    {"name": "zoneHash", "type": "bytes32"},
                    {"name": "salt", "type": "uint256"},
                    {"name": "conduitKey", "type": "bytes32"},
                    {"name": "counter", "type": "uint256"}
                ],
                "OfferItem": [
                    {"name": "itemType", "type": "uint8"},
                    {"name": "token", "type": "address"},
                    {"name": "identifierOrCriteria", "type": "uint256"},
                    {"name": "startAmount", "type": "uint256"},
                    {"name": "endAmount", "type": "uint256"}
                ],
                "ConsiderationItem": [
                    {"name": "itemType", "type": "uint8"},
                    {"name": "token", "type": "address"},
                    {"name": "identifierOrCriteria", "type": "uint256"},
                    {"name": "startAmount", "type": "uint256"},
                    {"name": "endAmount", "type": "uint256"},
                    {"name": "recipient", "type": "address"}
                ],
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                    {"name": "verifyingContract", "type": "address"}
                ]
            },
            "domain": {
                "name": "Seaport",
                "version": "1.6",
                "chainId": "0x17cc4",
                "verifyingContract": "0x0000000000000068f116a894984e2db1123eb395"
            },
            "primaryType": "OrderComponents",
            "message": {
                "offerer": self.wallet_address,
                "zone": self.web3.to_checksum_address("0xcef2071b4246db4d0e076a377348339f31a07dea"),
                "offer": [
                    {
                        "itemType": 1,
                        "token": "0x6f898cd313dcee4d28a87f675bd93c471868b0ac",
                        "identifierOrCriteria": "0",
                        "startAmount": str(amount),
                        "endAmount": str(amount)
                    }
                ],
                "consideration": [
                    {
                        "itemType": 2,
                        "token": "0x424bdf2e8a6f52bd2c1c81d9437b0dc0309df90f",
                        "identifierOrCriteria": str(domain.tokenId),
                        "startAmount": "1",
                        "endAmount": "1",
                        "recipient": self.wallet_address
                    },
                    {
                        "itemType": 1,
                        "token": "0x6f898cd313dcee4d28a87f675bd93c471868b0ac",
                        "identifierOrCriteria": "0",
                        "startAmount": str(fee1_amount),
                        "endAmount": str(fee1_amount),
                        "recipient": self.web3.to_checksum_address(fee1_recipient)
                    },
                    {
                        "itemType": 1,
                        "token": "0x6f898cd313dcee4d28a87f675bd93c471868b0ac",
                        "identifierOrCriteria": "0",
                        "startAmount": str(fee2_amount),
                        "endAmount": str(fee2_amount),
                        "recipient": self.web3.to_checksum_address(fee2_recipient)
                    }
                ],
                "orderType": 2,
                "startTime": str(start_time),
                "endTime": str(end_time),
                "zoneHash": "0x0000000000000000000000000000000000000000000000000000000000000000",
                "salt": salt,
                "conduitKey": "0x0000000000000000000000000000000000000000000000000000000000000000",
                "counter": "0"
            }
        }
        structured_msg = encode_typed_data(full_message=data)
        signed_data = self.account.sign_message(structured_msg)
        signature = signed_data.signature.hex()
        return '0x' + signature, data['message']

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def send_galxe_claim_tx(self, transaction_data):
        contract = self.load_contract(
            address=transaction_data['spaceStationInfo']['address'],
            abi=GalxeData.abi,
            web3=self.web3
        )

        last_block = await self.web3.eth.get_block('latest')
        max_priority_fee_per_gas = await self.web3.eth.max_priority_fee
        base_fee = int(last_block['baseFeePerGas'] * 1.15)
        max_fee_per_gas = base_fee + max_priority_fee_per_gas

        tx = await contract.functions.claimCapped(
            transaction_data['mintFuncInfo']['powahs'][0],
            self.web3.to_checksum_address(transaction_data['mintFuncInfo']['nftCoreAddress']),
            transaction_data['mintFuncInfo']['verifyIDs'][0],
            transaction_data['mintFuncInfo']['powahs'][0],
            transaction_data['mintFuncInfo']['cap'],
            int(transaction_data['mintFuncInfo']['claimFeeAmount']),
            transaction_data['signature']
        ).build_transaction({
            'from': self.wallet_address,
            'value': int(transaction_data['mintFuncInfo']['claimFeeAmount']),
            'nonce': await self.web3.eth.get_transaction_count(self.wallet_address),
            "maxPriorityFeePerGas": max_priority_fee_per_gas,
            "maxFeePerGas": max_fee_per_gas,
        })
        tx_hash = await self.sign_transaction(tx)
        confirmed = await self.wait_until_tx_finished(tx_hash)
        if confirmed:
            logger.success(
                f'[{self.wallet_address}] | Successfully claimed Galxe NFT '
                f'| TX: https://basescan.org/tx/{tx_hash}'
            )
            return tx_hash
