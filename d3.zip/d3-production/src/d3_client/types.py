from dataclasses import dataclass
from typing import List, Optional, Literal


@dataclass
class LinkedAccount:
    type: str
    address: str
    verified_at: int
    first_verified_at: int
    latest_verified_at: int
    chain_type: Optional[str] = None
    chain_id: Optional[str] = None
    wallet_client: Optional[str] = None
    wallet_client_type: Optional[str] = None
    connector_type: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> 'LinkedAccount':
        return cls(
            type=data["type"],
            address=data["address"],
            verified_at=data["verified_at"],
            first_verified_at=data["first_verified_at"],
            latest_verified_at=data["latest_verified_at"],
            chain_type=data.get("chain_type"),
            chain_id=data.get("chain_id"),
            wallet_client=data.get("wallet_client"),
            wallet_client_type=data.get("wallet_client_type"),
            connector_type=data.get("connector_type"),
        )


@dataclass
class User:
    id: str
    created_at: int
    linked_accounts: List[LinkedAccount]
    mfa_methods: List[str]
    has_accepted_terms: bool
    is_guest: bool

    def to_dict(self):
        return {
            "id": self.id,
            "created_at": self.created_at,
            "linked_accounts": [la.__dict__ for la in self.linked_accounts],
            "mfa_methods": self.mfa_methods,
            "has_accepted_terms": self.has_accepted_terms,
            "is_guest": self.is_guest,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'User':
        return cls(
            id=data["id"],
            created_at=data["created_at"],
            linked_accounts=[LinkedAccount.from_dict(la) for la in data.get("linked_accounts", [])],
            mfa_methods=data.get("mfa_methods", []),
            has_accepted_terms=data["has_accepted_terms"],
            is_guest=data["is_guest"],
        )


@dataclass
class AuthResponse:
    user: User
    token: str
    privy_access_token: Optional[str]
    refresh_token: str
    session_update_action: Literal["set", "clear", "update"]
    is_new_user: bool

    def to_dict(self):
        return {
            "user": self.user.to_dict(),
            "token": self.token,
            "privy_access_token": self.privy_access_token,
            "refresh_token": self.refresh_token,
            "session_update_action": self.session_update_action,
            "is_new_user": self.is_new_user,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'AuthResponse':
        return cls(
            user=User.from_dict(data["user"]),
            token=data["token"],
            privy_access_token=data.get("privy_access_token"),
            refresh_token=data["refresh_token"],
            session_update_action=data["session_update_action"],
            is_new_user=data["is_new_user"],
        )


@dataclass
class Referrals:
    accepted: List[str]
    pending: List[str]

    @classmethod
    def from_dict(cls, data: dict) -> 'Referrals':
        return cls(
            accepted=data.get("accepted", []),
            pending=data.get("pending", [])
        )


@dataclass
class ProfileData:
    premiumDomainsCount: Optional[int]
    nonPremiumDomainsCount: Optional[int]
    registrars: List[str]

    @classmethod
    def from_dict(cls, data: dict) -> 'ProfileData':
        return cls(
            premiumDomainsCount=data.get("premiumDomainsCount"),
            nonPremiumDomainsCount=data.get("nonPremiumDomainsCount"),
            registrars=data.get("registrars", [])
        )


@dataclass
class UserResponse:
    referralLink: str
    referrals: Referrals
    skipSteps: bool
    profileCompleted: bool
    profileData: ProfileData

    @classmethod
    def from_dict(cls, data: dict) -> 'UserResponse':
        return cls(
            referralLink=data["referralLink"],
            referrals=Referrals.from_dict(data["referrals"]),
            skipSteps=data["skipSteps"],
            profileCompleted=data["profileCompleted"],
            profileData=ProfileData.from_dict(data["profileData"]),
        )


@dataclass
class Currency:
    decimals: int
    name: str
    symbol: str


@dataclass
class Registrar:
    name: str
    ianaId: str
    publicKeys: List[str]
    websiteUrl: str
    supportEmail: str


@dataclass
class Chain:
    name: str
    networkId: str


@dataclass
class DomainItem:
    id: str
    externalId: str
    price: str
    offererAddress: str
    orderbook: str
    expiresAt: str
    createdAt: str
    updatedAt: str
    name: str
    nameExpiresAt: str
    currency: Currency
    registrar: Registrar
    tokenId: str
    chain: Chain

    @classmethod
    def from_dict(cls, data: dict) -> 'DomainItem':
        return cls(
            id=data["id"],
            externalId=data["externalId"],
            price=data["price"],
            offererAddress=data["offererAddress"],
            orderbook=data["orderbook"],
            expiresAt=data["expiresAt"],
            createdAt=data["createdAt"],
            updatedAt=data["updatedAt"],
            name=data["name"],
            nameExpiresAt=data["nameExpiresAt"],
            currency=Currency(**data["currency"]),
            registrar=Registrar(**data["registrar"]),
            tokenId=data["tokenId"],
            chain=Chain(**data["chain"]),
        )
