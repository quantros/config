import uuid
from asyncio import sleep
from datetime import datetime, timezone
from typing import Optional

from curl_cffi.requests import AsyncSession
from loguru import logger

from src.d3_client.session_collector import SessionCollector
from src.d3_client.types import AuthResponse, UserResponse
from src.utils.cherry_solver.client import CherrySolver
from src.utils.imap_client.imap import AsyncEmailChecker
from src.utils.proxy_manager import Proxy
from src.utils.user.account import Account


class AuthClient(Account):
    def __init__(
            self,
            session: AsyncSession,
            email_login: str,
            email_password: str,
            private_key: str,
            proxy: Proxy | None
    ):
        super().__init__(private_key=private_key, proxy=proxy)
        self.proxy = proxy
        self.email_login = email_login
        self.email_password = email_password
        self.session = session
        self.headers = {}
        self.cached_auth_response = None
        self._email_client = AsyncEmailChecker(email_login, email_password)
        self._captcha_solver = CherrySolver(
            session=self.session, proxy=self.proxy, verbose=True
        )

    @classmethod
    async def create(
            cls,
            session: AsyncSession,
            email_login: str,
            email_password: str,
            private_key: str,
            proxy: Proxy | None
    ):
        self = cls(session, email_login, email_password, private_key, proxy)
        collector = SessionCollector()

        if collector.has_session(email_login):
            self.session, cached_auth_data, saved_headers = await collector.load_session(email_login)
            self.headers = saved_headers
            self.cached_auth_response = AuthResponse.from_dict(cached_auth_data)
            logger.info(f"[{email_login}] | Reusing session from file.")
        else:
            self.headers = {
                'accept': 'application/json',
                'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
                'content-type': 'application/json',
                'origin': 'https://dashboard-testnet.doma.xyz',
                'priority': 'u=1, i',
                'privy-app-id': 'cm9jd3vun03ptju0knmkls1zp',
                'privy-ca-id': str(uuid.uuid4()),
                'privy-client': 'react-auth:2.16.0',
                'privy-ui': 't',
                'referer': 'https://dashboard-testnet.doma.xyz/',
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
            }

        return self

    async def get_user(self) -> Optional[UserResponse | str]:
        response = await self.session.request(
            method="GET",
            url='https://dashboard-testnet.doma.xyz/api/user/me',
            headers=self.headers
        )
        if response.status_code == 200:
            return UserResponse.from_dict(response.json())
        elif response.status_code == 401:
            return "UNAUTHORIZED"
        elif response.status_code == 404:
            return "NOT_CREATED"

    async def authorize(self) -> Optional[AuthResponse]:
        collector = SessionCollector()

        if self.cached_auth_response:
            return self.cached_auth_response

        code_sent = await self._send_verification_code()
        if not code_sent:
            return None

        await sleep(5)
        code = await self._email_client.check_email_for_verification_link(pattern=r"\b\d{6}\b")
        if not code:
            logger.error(f'[{self.email_login}] | Failed to get verification code.')
            return None

        response = await self.session.request(
            method="POST",
            url='https://privy.doma.xyz/api/v1/passwordless/authenticate',
            headers=self.headers,
            json={
                'email': self.email_login,
                'code': code,
                'mode': 'login-or-sign-up',
            }
        )
        if response.status_code == 200:
            json_data = response.json()
            self.headers.update({'authorization': f'Bearer {json_data["token"]}'})
            logger.success(f'[{self.email_login}] | Successfully authorized into Doma.xyz')

            await collector.save_session(self.email_login, self.session, json_data, self.headers)

            self.cached_auth_response = AuthResponse.from_dict(json_data)
            return self.cached_auth_response

        return None

    async def skip_personal_info(self):
        json_data = {
            'skipSteps': True,
        }
        await self.session.request(
            method="PUT",
            url='https://dashboard-testnet.doma.xyz/api/user/me',
            headers=self.headers,
            json=json_data
        )

    async def _confirm_verification_code(self, code: str) -> Optional[AuthResponse]:
        json_data = {
            'email': self.email_login,
            'code': code,
            'mode': 'login-or-sign-up',
        }
        response = await self.session.request(
            method="POST",
            url='https://privy.doma.xyz/api/v1/passwordless/authenticate',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200:
            jwt_token = response.json()['token']
            self.headers.update({'authorization': f'Bearer {jwt_token}'})
            logger.success(f'[{self.email_login}] | Successfully authorized into Doma.xyz')
            return AuthResponse.from_dict(response.json())

    async def _send_verification_code(self):
        site_key = '0x4AAAAAAAM8ceq5KhP1uJBt'
        turnstile_token = await self._captcha_solver.solve_captcha(
            captcha_name='turnstile',
            data_for_solver={
                'websiteKey': site_key,
                'websiteURL': 'https://dashboard-testnet.doma.xyz/'
            }
        )

        json_data = {
            'email': self.email_login,
            'token': turnstile_token,
        }

        response = await self.session.request(
            method="POST",
            url='https://privy.doma.xyz/api/v1/passwordless/init',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200 and response.json()['success']:
            logger.success(f'[{self.email_login}] | Email code successfully sent!')
            return True
        logger.error(f'Failed to send verification email code. Status code: {response.status_code}')

    async def _get_signature_data(self) -> Optional[dict]:
        json_data = {
            'address': self.wallet_address,
        }
        response = await self.session.request(
            method="POST",
            url='https://privy.doma.xyz/api/v1/siwe/init',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200:
            return response.json()

    async def link_wallet(self) -> Optional[bool]:
        signature_data = await self._get_signature_data()
        current_time = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        message = f"""dashboard-testnet.doma.xyz wants you to sign in with your Ethereum account:
{self.wallet_address}

By signing, you are proving you own this wallet and logging in. This does not initiate a transaction or cost any fees.

URI: https://dashboard-testnet.doma.xyz
Version: 1
Chain ID: 1
Nonce: {signature_data['nonce']}
Issued At: {current_time}
Resources:
- https://privy.io"""

        signature = self.get_signature(message)

        json_data = {
            'message': message,
            'signature': signature,
            'chainId': 'eip155:1',
            'walletClientType': 'rabby_wallet',
            'connectorType': 'injected',
        }
        response = await self.session.request(
            method="POST",
            url='https://privy.doma.xyz/api/v1/siwe/link',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200:
            logger.success(f'[{self.wallet_address}] | Successfully linked wallet!')
            return True

    async def activate_account(self):
        json_data = {
            'referralCode': '',
        }
        response = await self.session.request(
            method="POST",
            url='https://dashboard-testnet.doma.xyz/api/user/me',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200 and response.json()['success']:
            logger.success(f'[{self.email_login}] | Account activated!')
            if self.cached_auth_response:
                self.cached_auth_response.is_new_user = False
            else:
                logger.warning(f'[{self.email_login}] | Warning: cached_auth_response is None during activation')
            await SessionCollector().save_session(
                self.email_login,
                self.session,
                self.cached_auth_response.to_dict(),
                self.headers
            )
            return True
