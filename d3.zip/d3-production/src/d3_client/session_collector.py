import pickle
from pathlib import Path
from typing import Optional
from curl_cffi.requests import AsyncSession


class SessionCollector:
    _instance = None
    _session_dir = Path("sessions")

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SessionCollector, cls).__new__(cls)
            cls._session_dir.mkdir(exist_ok=True)
        return cls._instance

    def get_session_path(self, email: str) -> Path:
        sanitized_email = email.replace("@", "_at_").replace(":", "_")
        return self._session_dir / f"{sanitized_email}.pkl"

    def has_session(self, email: str) -> bool:
        return self.get_session_path(email).exists()

    async def load_session(self, email: str) -> Optional[tuple[AsyncSession, dict, dict]]:
        path = self.get_session_path(email)
        if not path.exists():
            return None

        with open(path, "rb") as f:
            data = pickle.load(f)

        session = AsyncSession()
        session.cookies.update(data["cookies"])
        session.headers.update(data["headers"])
        return session, data["auth_response_json"], data['headers']

    async def save_session(self, email: str, session: AsyncSession, auth_response_json: dict, headers: dict):
        path = self.get_session_path(email)
        data = {
            "cookies": session.cookies.get_dict(),
            "headers": headers,
            "auth_response_json": auth_response_json
        }
        with open(path, "wb") as f:
            pickle.dump(data, f)

    def delete_session(self, email: str):
        path = self.get_session_path(email)
        if path.exists():
            path.unlink()
