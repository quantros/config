from wordfreq import zipf_frequency


def extract_sld(fqdn: str) -> str:
    if not fqdn:
        return ""
    return fqdn.split(".")[0].lower()


def is_real_english_word(sld: str) -> bool:
    s = sld.strip().lower()
    if not s.isalpha():
        return False
    if zipf_frequency is None:
        return len(s) >= 2
    try:
        return zipf_frequency(s, "en") >= 3.5
    except Exception:
        return False


def is_finance_thematic(sld: str) -> bool:
    s = sld.lower()
    keywords = {
        "fin", "pay", "bank", "cash", "coin", "fund", "lend", "loan", "save",
        "tax", "risk", "bond", "etf", "reit", "swap", "defi", "cefi", "dao",
        "ape"
    }
    if len(s) > 5:
        return False
    return any(k in s for k in keywords)


def is_brand_baron6(domain: str) -> bool:
    parts = domain.lower().split('.')
    sld = parts[0]
    if not (sld.isalpha() and len(sld) <= 6):
        return False
    return any(p.endswith(("ly", "io", "fy")) for p in parts[1:])


def looks_like_product_noun(s: str) -> bool:
    s = s.strip().lower()
    if not s.isalpha():
        return False

    bad_suffixes = (
        "ing", "ed", "ism", "ness", "ment", "tion", "sion",
        "ship", "hood", "ity", "ful", "less", "able", "ous",
        "ive", "ly"
    )
    if any(s.endswith(sf) for sf in bad_suffixes):
        return False

    short_whitelist = {
        "pc", "tv", "vr", "ai", "cpu", "gpu", "ram", "ink", "pad"
    }
    if s in short_whitelist:
        return True

    try:
        freq = zipf_frequency(s, "en")
    except Exception:
        freq = 0.0

    return freq >= 3.5


def is_commerce_commander(domain: str) -> bool:
    if not domain:
        return False
    parts = domain.lower().split(".")
    sld = parts[0]

    if not (sld.isalpha() and 2 <= len(sld) <= 6):
        return False

    return looks_like_product_noun(sld)


def is_pitch_perfect(domain: str) -> bool:
    if not domain:
        return False
    parts = domain.lower().split(".")
    sld = parts[0]
    if not sld.isalpha():
        return False
    return sld.endswith(("hub", "stack", "works"))


def is_click_king(domain: str) -> bool:
    if not domain:
        return False
    sld = extract_sld(domain)
    if not sld.isalpha():
        return False
    needles = ("free", "deal", "fast", "hot")
    s = sld.lower()
    return any(n in s for n in needles)
