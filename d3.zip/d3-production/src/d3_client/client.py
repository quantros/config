import random
from asyncio import sleep
from typing import Optional

from loguru import logger
from faker import Faker

from config import DomainOfferSettings, RETRIES, PAUSE_BETWEEN_RETRIES, PAUSE_BETWEEN_MODULES, GalxeSettings
from src.d3_client.auth_client import AuthClient
from src.d3_client.onchain_client import OnchainClient
from src.d3_client.session_collector import SessionCollector
from src.d3_client.types import AuthResponse, DomainItem, UserResponse
from src.d3_client.word_tools import is_finance_thematic, extract_sld, is_real_english_word, is_brand_baron6, \
    is_commerce_commander, is_pitch_perfect, is_click_king
from src.galxe.galxe_actions import GalxeClient
from src.models.contracts import DomainData, ERC20
from src.modules.swaps.wrapper.wrapper import Wrapper
from src.utils.common.wrappers.decorators import retry
from src.utils.data.tokens import tokens
from src.utils.proxy_manager import Proxy


class D3Client(GalxeClient):
    def __init__(
            self,
            private_key: str,
            proxy: Proxy | None,
            twitter_token: str = None,
            discord_token: str = None,
            email: str = None
    ):
        email_login, email_password = email.split(":")

        super().__init__(
            private_key=private_key,
            proxy=proxy,
            twitter_token=twitter_token,
            discord_token=discord_token,
            email_login=email_login,
            email_password=email_password
        )
        self._auth_client = None
        self._email = email
        self._private_key = private_key
        self._proxy = proxy

        self._onchain_client = OnchainClient(private_key=private_key, proxy=proxy, session=self.session)
        self.headers = None
        self.api_key = 'v1.765e3386c5b7dea6a128443cbf73ecbdb29110b269fe1f472265154d1fc419d8'
        self.auth_data = None

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def initialize_auth_client(self):
        if self._email:
            email_login, email_password = self._email.split(":")
            self._auth_client = await AuthClient.create(
                self.session, email_login, email_password, self._private_key, self._proxy
            )

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def prepare_work(self):
        await self.prepare_account()

    async def _verify_on_discord_server(self):
        joined = await self._discord_client.join_server(invite_code='Doma')
        if joined:
            logger.success(f'[{self.wallet_address}] | Successfully joined Discord server!')
            params = {
                'location': 'Message Inline Button',
                'type': '0',
            }
            response = await self.session.request(
                method="PUT",
                url='https://discord.com/api/v9/channels/1220816434980982995/messages/1387396245894463540/reactions/doma%3A1340461177658146897/%40me',
                params=params,
                headers={'authorization': self.discord_token}
            )
            if response.status_code == 204:
                logger.success(f'[{self.wallet_address}] | Successfully verified on Discord server!')
                return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def prepare_galaxy_client_for_quests(self):
        await self.prepare_work()
        followed_d3 = await self._twitter_client.follow(user_id=1879793280105541632)
        await sleep(3)
        if followed_d3:
            logger.success(f'[{self.wallet_address}] | Successfully followed D3')
        followed_d3_inc = await self._twitter_client.follow(user_id=1697095575806885888)
        await sleep(3)
        if followed_d3_inc:
            logger.success(f'[{self.wallet_address}] | Successfully followed D3inc')
        await sleep(3)
        followed_hey_hey_fred = await self._twitter_client.follow(user_id=1297307288785416194)
        if followed_hey_hey_fred:
            logger.success(f'[{self.wallet_address}] | Successfully followed heyheyfred!')
        await sleep(3)
        followed_mxchaelho = await self._twitter_client.follow(user_id=779497794285424640)
        if followed_mxchaelho:
            logger.success(f'[{self.wallet_address}] | Successfully followed Michael Ho.')
        await sleep(3)
        liked = await self._twitter_client.like(tweet_id=1956031593992130624)
        if liked:
            logger.success(f'[{self.wallet_address}] | Successfully liked tweet!')
        await sleep(3)
        retweeted = await self._twitter_client.retweet(tweet_id=1956031593992130624)
        if retweeted:
            logger.success(f'[{self.wallet_address}] | Successfully retweeted tweet!')

        await self._verify_on_discord_server()

    async def complete_galxe(self):
        await self.prepare_galaxy_client_for_quests()
        campaigns = GalxeSettings.campaign_ids
        successes = 0
        for campaign in campaigns:
            completed = await self.process_campaign(campaign_id=campaign)
            if completed:
                successes += 1
            random_pause = random.randint(PAUSE_BETWEEN_MODULES[0], PAUSE_BETWEEN_MODULES[1])
            logger.debug(f'[{self.wallet_address}] | Sleeping {random_pause} seconds before next campaign...')
            await sleep(random_pause)
        if successes > 0:
            return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def link_wallet(self) -> Optional[bool]:
        return await self._auth_client.link_wallet()

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _fetch_listed_page(self, skip: int, take: int = 8):
        json_data = {
            'query': 'query listings($skip: Float, $take: Float, $tlds: [String!]) {\n  listings(skip: $skip, take: $take, tlds: $tlds) {\n    items {\n      id\n      externalId\n      price\n      offererAddress\n      orderbook\n      expiresAt\n      createdAt\n      updatedAt\n      name\n      nameExpiresAt\n      currency {\n        decimals\n        name\n        symbol\n      }\n      registrar {\n        name\n        ianaId\n        publicKeys\n        websiteUrl\n        supportEmail\n      }\n      tokenId\n      chain {\n        name\n        networkId\n      }\n    }\n    totalCount\n    pageSize\n    currentPage\n    totalPages\n    hasPreviousPage\n    hasNextPage\n  }\n}',
            'variables': {'skip': float(skip), 'take': float(take), 'tlds': []},
            'operationName': 'listings',
        }
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})
        response = await self.session.request(
            method="POST",
            url='https://api-testnet.doma.xyz/graphql',
            headers=headers,
            json=json_data
        )
        response_json = response.json()
        listings_data = response_json["data"]["listings"]
        items = [DomainItem.from_dict(item) for item in listings_data.get("items", [])]
        has_next = bool(listings_data.get("hasNextPage"))
        next_skip = skip + take if has_next else 0
        return items, has_next, next_skip

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def get_domain_transaction_data(self, domain: DomainItem):
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})

        response = await self.session.request(
            method="GET",
            url=f'https://api-testnet.doma.xyz/v1/orderbook/listing/{domain.externalId}/{self.wallet_address}',
            headers=headers
        )
        if response.status_code == 200:
            return response.json()
        logger.error(f'[{self.wallet_address}] | Failed to get {domain.name} mint data.')

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def get_domain_info(self, domain_name: str):
        json_data = {
            'query': 'query Name($name: String!) {\n  name(name: $name) {\n    name\n    expiresAt\n    tokenizedAt\n    eoi\n    isFractionalized\n    fractionalTokenInfo {\n      address\n      poolAddress\n      fractionalizedAt\n      boughtOutAt\n      buyoutPrice\n      status\n      params {\n        name\n        symbol\n        initialValuation\n        launchStartDate\n      }\n    }\n    registrar {\n      name\n      ianaId\n      publicKeys\n      websiteUrl\n    }\n    nameservers {\n      ldhName\n    }\n    dsKeys {\n      keyTag\n      algorithm\n      digest\n      digestType\n    }\n    transferLock\n    claimedBy\n    tokens {\n      tokenId\n      networkId\n      ownerAddress\n      type\n      startsAt\n      expiresAt\n      explorerUrl\n      createdAt\n      tokenAddress\n      listings {\n        id\n        externalId\n        price\n        offererAddress\n        orderbook\n        expiresAt\n        createdAt\n        updatedAt\n        currency {\n          decimals\n          name\n          symbol\n        }\n      }\n      chain {\n        name\n        networkId\n        addressUrlTemplate\n      }\n      orderbookDisabled\n      activities {\n        ... on TokenBoughtOutActivity {\n          type\n          createdAt\n        }\n        ... on TokenFractionalizedActivity {\n          type\n          createdAt\n        }\n        ... on TokenListedActivity {\n          type\n          createdAt\n        }\n        ... on TokenListingCancelledActivity {\n          type\n          createdAt\n        }\n        ... on TokenMintedActivity {\n          type\n          createdAt\n        }\n        ... on TokenOfferCancelledActivity {\n          type\n          createdAt\n        }\n        ... on TokenOfferReceivedActivity {\n          type\n          buyer\n          seller\n          createdAt\n        }\n        ... on TokenPurchasedActivity {\n          type\n          buyer\n          seller\n          createdAt\n        }\n        ... on TokenTransferredActivity {\n          type\n          transferredTo\n          transferredFrom\n          createdAt\n        }\n      }\n    }\n    activities {\n      ... on NameClaimedActivity {\n        type\n        txHash\n        sld\n        tld\n        createdAt\n        claimedBy\n      }\n      ... on NameRenewedActivity {\n        type\n        txHash\n        sld\n        tld\n        createdAt\n        expiresAt\n      }\n      ... on NameDetokenizedActivity {\n        type\n        txHash\n        sld\n        tld\n        createdAt\n        networkId\n      }\n      ... on NameTokenizedActivity {\n        type\n        txHash\n        sld\n        tld\n        createdAt\n        networkId\n      }\n      ... on NameClaimApprovedActivity {\n        type\n        createdAt\n      }\n      ... on NameClaimRejectedActivity {\n        type\n        createdAt\n      }\n      ... on NameClaimRequestedActivity {\n        type\n        createdAt\n      }\n    }\n  }\n}',
            'variables': {
                'name': domain_name,
            },
            'operationName': 'Name',
        }
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})
        i = 0
        while i < 10:
            i += 1
            response = await self.session.request(
                method="POST",
                url='https://api-testnet.doma.xyz/graphql',
                headers=headers,
                json=json_data
            )
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(
                    f'[{self.wallet_address}] | Failed to get domain info | Status: {response.status_code}'
                )
                await sleep(5)

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def get_claim_data(self, domain_info: dict):
        fake = Faker()
        iana_id = int(domain_info['data']['name']['registrar']['ianaId'])

        json_data = {
            'networkId': 'eip155:97476',
            'registrarIanaId': iana_id,
            'contact': {
                'name': fake.name(),
                'email': self._auth_client.email_login,
                'postalCode': fake.postcode(),
                'countryCode': 'AO',
                'state': fake.state_abbr(),
                'street': fake.street_address(),
                'city': fake.city(),
                'organization': fake.company(),
                'phone': f"+1{random.randint(6000000000, 6999999999)}",
            },
        }

        response = await self.session.request(
            method="POST",
            url='https://dashboard-testnet.doma.xyz/api/domain/claim',
            headers=self.headers,
            json=json_data
        )
        if response.status_code == 200:
            return response.json()
        logger.error(f'[{self.wallet_address}] | Failed to get claim data | Status: {response.status_code}')

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def buy_domain(self, max_percentage_of_balance: float, mode: str | None = None) -> Optional[bool]:
        native_balance = await self.get_wallet_balance(is_native=True)
        if native_balance == 0:
            logger.error(f'[{self.wallet_address}] | Native balance is 0.')
            return None

        def _passes_mode(domain_name: str) -> bool:
            sld = extract_sld(domain_name)
            if mode is None:
                return True
            if mode == "wordlord_real4":
                return len(sld) <= 4 and is_real_english_word(sld)
            if mode == "tycoon_tech5":
                return is_finance_thematic(sld) and sld.isalpha()
            if mode == 'brand_baron6':
                return is_brand_baron6(domain_name)
            if mode == 'commerce_commander':
                return is_commerce_commander(domain_name)
            if mode == 'pitch_perfect':
                return is_pitch_perfect(domain_name)
            if mode == 'click_king':
                return is_click_king(domain_name)
            return True

        skip = 0
        take = 8
        cheapest_domain = None
        tx_data = None

        logger.debug(f'[{self.wallet_address}] | Searching for a suitable domain...')
        while True:
            items, has_next, next_skip = await self._fetch_listed_page(skip=skip, take=take)

            eth_doma_domains = [
                d for d in items
                if d.chain.name == "Doma Testnet"
                   and d.currency.symbol == 'ETH'
                   and int(d.price) < int(native_balance * max_percentage_of_balance)
                   and _passes_mode(d.name)
            ]

            if not eth_doma_domains:
                if has_next:
                    skip = next_skip
                    await sleep(1)
                    continue
                else:
                    skip = 0
                    await sleep(3)
                    continue

            cheapest_domain = min(eth_doma_domains, key=lambda d: int(d.price))
            tx_data = await self.get_domain_transaction_data(domain=cheapest_domain)
            if not tx_data:
                logger.warning(
                    f'[{self.wallet_address}] | Failed to get tx data for {cheapest_domain.name}...')
                if has_next:
                    skip = next_skip
                else:
                    skip = 0
                await sleep(2)
                continue
            break

        tx_hash = await self._onchain_client.buy_domain(tx_data, int(cheapest_domain.price))
        if tx_hash:
            logger.success(
                f'[{self.wallet_address}] | Successfully bought {cheapest_domain.name} (mode={mode}) '
                f'| TX: https://explorer-testnet.doma.xyz/tx/{tx_hash}'
            )
            await sleep(10)
            domain_info = await self.get_domain_info(cheapest_domain.name)
            claim_data = await self.get_claim_data(domain_info)
            if not claim_data:
                return None
            claim_tx_hash = await self._onchain_client.claim_domain(claim_data, domain_info)
            if claim_tx_hash:
                logger.success(
                    f'[{self.wallet_address}] | Successfully claimed {cheapest_domain.name} '
                    f'| TX: https://explorer-testnet.doma.xyz/tx/{claim_tx_hash}'
                )
                return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def get_owned_domains(self) -> Optional[list]:
        json_data = {
            'query': 'query Names($claimStatus: NamesQueryClaimStatus, $ownedBy: [AddressCAIP10!], $name: String, $tlds: [String!], $networkIds: [String!], $registrarIanaIds: [Int!], $fractionalized: Boolean, $listed: Boolean, $active: Boolean, $take: Int, $skip: Int, $sortBy: NamesQuerySortBy, $sortOrder: SortOrderType) {\n  names(\n    claimStatus: $claimStatus\n    ownedBy: $ownedBy\n    name: $name\n    tlds: $tlds\n    networkIds: $networkIds\n    registrarIanaIds: $registrarIanaIds\n    fractionalized: $fractionalized\n    listed: $listed\n    active: $active\n    take: $take\n    skip: $skip\n    sortBy: $sortBy\n    sortOrder: $sortOrder\n  ) {\n    totalCount\n    pageSize\n    currentPage\n    totalPages\n    hasPreviousPage\n    hasNextPage\n    items {\n      isFractionalized\n      fractionalTokenInfo {\n        address\n        buyoutPrice\n        fractionalizedAt\n        status\n        params {\n          name\n          symbol\n          initialValuation\n          launchStartDate\n        }\n      }\n      name\n      expiresAt\n      tokenizedAt\n      eoi\n      registrar {\n        name\n        websiteUrl\n        ianaId\n        publicKeys\n      }\n      nameservers {\n        ldhName\n      }\n      dsKeys {\n        keyTag\n        algorithm\n        digest\n        digestType\n      }\n      transferLock\n      claimedBy\n      tokens {\n        tokenId\n        networkId\n        ownerAddress\n        type\n        startsAt\n        expiresAt\n        listings {\n          expiresAt\n          offererAddress\n          price\n          currency {\n            decimals\n            name\n            symbol\n          }\n        }\n        chain {\n          name\n          networkId\n        }\n      }\n    }\n  }\n}',
            'variables': {
                'skip': 0,
                'take': 20,
                'ownedBy': [
                    f'eip155:1:{self.wallet_address}',
                ],
                'claimStatus': 'ALL',
            },
            'operationName': 'Names',
        }
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})
        response = await self.session.request(
            method="POST",
            url='https://api-testnet.doma.xyz/graphql',
            headers=headers,
            json=json_data
        )
        if response.status_code == 200:
            return [
                item for item in response.json()['data']['names']['items']
                if all(len(token.get('listings', [])) == 0 for token in item.get('tokens', []))
            ]

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def list_domain(self, price: float):
        owned_unlisted_domains = await self.get_owned_domains()
        if not owned_unlisted_domains:
            logger.warning(f'[{self.wallet_address}] | Owned domains not found.')
            return None

        domain_contract = self.load_contract(
            address='0x424bDf2E8a6F52Bd2c1C81D9437b0DC0309DF90f',
            abi=ERC20.abi,
            web3=self.web3
        )

        is_approved = await domain_contract.functions.isApprovedForAll(
            self.wallet_address,
            self.web3.to_checksum_address(DomainData.address)
        ).call()

        if not is_approved:
            try:
                tx = await domain_contract.functions.setApprovalForAll(
                    self.web3.to_checksum_address(DomainData.address),
                    True
                ).build_transaction({
                    'from': self.wallet_address,
                    'value': 0,
                    'gasPrice': await self.web3.eth.gas_price,
                    'nonce': await self.web3.eth.get_transaction_count(self.wallet_address)
                })
                tx_hash = await self.sign_transaction(tx)
                confirmed = await self.wait_until_tx_finished(tx_hash)
            except Exception as ex:
                logger.error(f'Approve failed: {ex}')
                return None

            if confirmed:
                logger.success(
                    f'[{self.wallet_address}] | Successfully approved domain |'
                    f' TX: https://explorer-testnet.doma.xyz/tx/{tx_hash}'
                )

        domain = random.choice(owned_unlisted_domains)
        domain_info = await self.get_domain_info(domain['name'])
        price = int(price * 10 ** 18)
        signature, data = await self._onchain_client.get_listing_signature(domain_info, price)
        json_data = {
            'signature': signature,
            'orderbook': 'DOMA',
            'chainId': 'eip155:97476',
            'parameters': {
                'offerer': data['offerer'],
                'zone': data['zone'],
                'zoneHash': data['zoneHash'],
                'startTime': data['startTime'],
                'endTime': data['endTime'],
                'orderType': int(data['orderType']),
                'offer': data['offer'],
                'consideration': data['consideration'],
                'totalOriginalConsiderationItems': len(data['consideration']),
                'salt': self.web3.to_hex(primitive=int(data['salt'])),
                'conduitKey': data['conduitKey'],
                'counter': data['counter'],
            },
            'cancelExisting': True,
        }
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})

        response = await self.session.request(
            method="POST",
            url='https://api-testnet.doma.xyz/v1/orderbook/list',
            headers=headers,
            json=json_data
        )
        if response.status_code == 200:
            logger.success(f'[{self.wallet_address}] | Successfully listed {domain['name']} domain!')
            return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def offer_domain(self, percentage: float):
        native_balance = await self.get_wallet_balance(is_native=True)
        if native_balance == 0:
            logger.error(f'[{self.wallet_address}] | Native balance is 0.')
        weth_balance = await self.get_wallet_balance(
            is_native=False, address=tokens['DOMA']['WETH']
        )
        if weth_balance == 0:
            logger.warning(f'[{self.wallet_address}] | WETH balance is 0 wrapping first...')
            percentage_to_wrap = random.uniform(
                DomainOfferSettings.percentage_to_wrap[0],
                DomainOfferSettings.percentage_to_wrap[1]
            ) if isinstance(DomainOfferSettings.percentage_to_wrap, list) else DomainOfferSettings.percentage_to_wrap

            wrapper = Wrapper(
                private_key=self.private_key,
                action='wrap',
                amount=0,
                use_all_balance=False,
                use_percentage=True,
                percentage_to_wrap=percentage_to_wrap,
                proxy=self.proxy
            )
            wrapped = await wrapper.wrap()
            if not wrapped:
                return None
            weth_balance = await self.get_wallet_balance(
                is_native=False, address=tokens['DOMA']['WETH']
            )

        amount = int(weth_balance * percentage)
        await self._onchain_client.call_approve(
            amount=amount,
            from_token_address=tokens['DOMA']['WETH'],
            spender=DomainData.address
        )

        listed_domains, _, _ = await self._fetch_listed_page(skip=0)
        eth_doma_domains = [
            domain for domain in listed_domains
            if domain.chain.name == "Doma Testnet" and domain.currency.symbol == 'ETH'
        ]
        domain: DomainItem = random.choice(eth_doma_domains)
        signature, data = await self._onchain_client.get_offer_signature(domain, amount)

        json_data = {
            'signature': signature,
            'orderbook': 'DOMA',
            'chainId': 'eip155:97476',
            'parameters': {
                'offerer': self.wallet_address,
                'zone': data['zone'],
                'zoneHash': data['zoneHash'],
                'startTime': data['startTime'],
                'endTime': data['endTime'],
                'orderType': data['orderType'],
                'offer': data['offer'],
                'consideration': data['consideration'],
                'totalOriginalConsiderationItems': len(data['consideration']),
                'salt': data['salt'],
                'conduitKey': data['conduitKey'],
                'counter': data['counter'],
            },
            'cancelExisting': True,
        }
        headers = self.headers.copy()
        headers.update({'api-key': self.api_key})
        response = await self.session.request(
            method="POST",
            url='https://api-testnet.doma.xyz/v1/orderbook/offer',
            headers=headers,
            json=json_data
        )
        if response.status_code == 200:
            logger.success(
                f'[{self.wallet_address}] | Successfully offered {domain.name} '
                f'domain for {round(amount / 10 ** 18, 4)} WETH'
            )
            return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def authorize(self) -> Optional[AuthResponse]:
        await self.initialize_auth_client()

        user = await self._auth_client.get_user()
        if user == 'UNAUTHORIZED':
            logger.warning(f'[{self._auth_client.email_login}] | Session expired. Re-authorizing...')
            SessionCollector().delete_session(self._auth_client.email_login)
            await self.initialize_auth_client()
            auth_response = await self._auth_client.authorize()
            if not auth_response:
                return None
            user = await self._auth_client.get_user()
        elif user == "NOT_CREATED":
            auth_response = self._auth_client.cached_auth_response or await self._auth_client.authorize()
            if not auth_response:
                logger.error(f'[{self._auth_client.email_login}] | Failed to authorize new account.')
                return None
        else:
            auth_response = self._auth_client.cached_auth_response or await self._auth_client.authorize()
        if auth_response.is_new_user:
            logger.debug(f'[{self._auth_client.email_login}] | New account detected. Activating...')
            await self._auth_client.activate_account()
            await sleep(3)
            user = await self._auth_client.get_user()
        if not user or (isinstance(user, UserResponse) and not user.skipSteps):
            await self._auth_client.skip_personal_info()

        self.auth_data = auth_response
        self.headers = self._auth_client.headers
        return auth_response
