from src.utils.runner import *

module_handlers = {
    'COMPLETE_GALXE': process_flipper_paradise,
    'COMPLETE_D3_PROFILE': complete_profile,
    'BUY_DOMAIN': process_buy_domain,
    'TESTNET_BRIDGE': process_testnet_bridge,
    'SUPER_BRIDGE': process_super_bridge,
    'LIST_DOMAIN': process_list_domain,
    'OFFER_DOMAIN': process_offer_domain
}
