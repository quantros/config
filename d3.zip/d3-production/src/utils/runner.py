import asyncio
import random
from asyncio import sleep
from typing import Optional, List, Dict

from loguru import logger

from config import TestnetBridgeConfig, SuperBridgeSettings, DomainListingSettings, DomainOfferSettings, \
    BuyDomainSettings, PAUSE_BETWEEN_MODULES
from src.d3_client.client import D3Client
from src.models.bridge import BridgeConfig
from src.models.chain import Chain
from src.models.route import Route
from src.models.token import Token
from src.modules.bridges.bridge_factory import SepoliaBridge, SuperBridge
from src.utils.data.chains import chain_mapping
from src.utils.proxy_manager import Proxy
from src.utils.user.account import Account


async def process_flipper_paradise(route: Route) -> Optional[bool]:
    d3_client = D3Client(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        twitter_token=route.wallet.twitter_token,
        discord_token=route.wallet.discord_token,
        email=route.wallet.email
    )
    return await d3_client.complete_galxe()


async def complete_profile(route: Route) -> Optional[bool]:
    d3_client = D3Client(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        email=route.wallet.email
    )
    auth_data = await d3_client.authorize()
    if not auth_data:
        return False

    linked_accounts = auth_data.user.linked_accounts
    wallets_linked = [account for account in linked_accounts if account.type == 'wallet']

    if not wallets_linked:
        return await d3_client.link_wallet()
    else:
        return True


async def process_buy_domain(route: Route) -> Optional[bool]:
    d3_client = D3Client(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        email=route.wallet.email
    )
    auth_data = await d3_client.authorize()
    if not auth_data:
        return False
    mode_mapping = {
        0: None,
        1: 'wordlord_real4',
        2: 'tycoon_tech5',
        3: 'brand_baron6',
        4: 'commerce_commander',
        5: 'pitch_perfect',
        6: 'click_king'
    }
    max_percentage_of_balance = random.uniform(
        BuyDomainSettings.max_percentage_of_balance[0],
        BuyDomainSettings.max_percentage_of_balance[1]
    )
    modes = BuyDomainSettings.mode if isinstance(BuyDomainSettings.mode, list) else [BuyDomainSettings.mode]
    successes = 0
    for mode in modes:
        mode = mode_mapping[mode]
        try:
            bought = await asyncio.wait_for(
                d3_client.buy_domain(max_percentage_of_balance=max_percentage_of_balance, mode=mode),
                timeout=600
            )
        except asyncio.TimeoutError:
            logger.warning(f"Не получилось найти подходящий домен (mode={mode}) за 10 минут, пропускаю...")
            bought = False

        if bought:
            successes += 1

        random_sleep = random.randint(PAUSE_BETWEEN_MODULES[0], PAUSE_BETWEEN_MODULES[1]) \
            if isinstance(PAUSE_BETWEEN_MODULES, list) else PAUSE_BETWEEN_MODULES
        logger.info(f'Сплю {random_sleep} секунд перед следующей покупкой домена...')
        await sleep(random_sleep)

    if successes > 0:
        return True


async def process_list_domain(route: Route) -> Optional[bool]:
    d3_client = D3Client(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        email=route.wallet.email
    )
    price = random.uniform(DomainListingSettings.price[0], DomainListingSettings.price[1])
    auth_data = await d3_client.authorize()
    if not auth_data:
        return False
    return await d3_client.list_domain(price)


async def process_offer_domain(route: Route) -> Optional[bool]:
    d3_client = D3Client(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        email=route.wallet.email
    )
    auth_data = await d3_client.authorize()
    if not auth_data:
        return False
    percentage = random.uniform(
        DomainOfferSettings.percentage_to_offer[0],
        DomainOfferSettings.percentage_to_offer[1]
    ) if isinstance(DomainOfferSettings.percentage_to_offer, list) else DomainOfferSettings.percentage_to_offer
    return await d3_client.offer_domain(percentage)


async def process_testnet_bridge(route: Route) -> Optional[bool]:
    proxy: Proxy = route.wallet.proxy
    while True:
        try:
            account = Account(
                private_key=route.wallet.private_key,
                rpc=chain_mapping['DOMA'].rpc,
                proxy=proxy
            )
            to_chain_balance = await account.get_wallet_balance(is_native=True)
            if to_chain_balance / 10 ** 18 > TestnetBridgeConfig.min_doma_eth_balance:
                logger.success(f'[{account.wallet_address}] | В сети Doma уже есть достаточное кол-во эфира')
                return True
            break
        except Exception as ex:
            if (
                    'proxy' in str(ex).lower() or
                    'http' in str(ex).lower() or
                    'host' in str(ex).lower() or
                    'timeout' in str(ex).lower()
            ):
                logger.debug('Changing proxy...')
                await proxy.change()

    chains = TestnetBridgeConfig.from_chain
    balances = await get_balances_for_chains(
        chains=chains,
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy
    )
    if not balances:
        return None
    from_chain = max(balances, key=balances.get)
    # logger.info(f'Found balance in {from_chain}')
    to_chain = TestnetBridgeConfig.to_chain
    amount = random.uniform(TestnetBridgeConfig.amount[0], TestnetBridgeConfig.amount[1])
    use_percentage = TestnetBridgeConfig.use_percentage
    bridge_percentage = TestnetBridgeConfig.bridge_percentage

    sepolia = SepoliaBridge(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        bridge_config=BridgeConfig(
            from_chain=Chain(
                chain_name=from_chain,
                native_token=chain_mapping[from_chain.upper()].native_token,
                rpc=chain_mapping[from_chain.upper()].rpc,
                chain_id=chain_mapping[from_chain.upper()].chain_id
            ),
            to_chain=Chain(
                chain_name=to_chain,
                native_token=chain_mapping[to_chain.upper()].native_token,
                rpc=chain_mapping[to_chain.upper()].rpc,
                chain_id=chain_mapping[to_chain.upper()].chain_id
            ),
            from_token=Token(
                chain_name=from_chain,
                name='ETH',
            ),
            to_token=Token(
                chain_name=to_chain,
                name='ETH',
            ),
            amount=amount,
            use_percentage=use_percentage,
            bridge_percentage=bridge_percentage
        )
    )
    to_chain_account = Account(
        private_key=route.wallet.private_key,
        rpc=chain_mapping['SEPOLIA'].rpc,
        proxy=None
    )
    to_chain_balance = await to_chain_account.get_wallet_balance(is_native=True)
    if to_chain_balance / 10 ** 18 > TestnetBridgeConfig.min_sepolia_eth_balance:
        logger.success(f'[{to_chain_account.wallet_address}] | В сети Sepolia уже есть достаточное кол-во эфира')
        return True

    logger.debug(sepolia)
    return await sepolia.bridge()


async def get_balances_for_chains(
        chains: List[str],
        private_key: str,
        proxy: Proxy | None = None
) -> Optional[Dict[str, int]]:
    balances = {}

    for chain_name in chains:
        rpc = chain_mapping[chain_name].rpc

        while True:
            account = Account(private_key=private_key, rpc=rpc, proxy=proxy)
            wallet_address = account.wallet_address
            try:
                balance = await account.web3.eth.get_balance(wallet_address)
                break
            except Exception as ex:
                logger.info(f'Не удалось проверить баланс | {ex}')
                if 'proxy' in str(ex).lower() or 'http' in str(ex).lower() or 'host' in str(ex):
                    logger.debug('Changing proxy...')
                    await proxy.change()
                await sleep(2)
        balances[chain_name] = balance

    return balances


async def process_super_bridge(route: Route) -> Optional[bool]:
    from_chain = SuperBridgeSettings.from_chain if isinstance(
        SuperBridgeSettings.from_chain, str) else random.choice(SuperBridgeSettings.from_chain)

    to_chain = SuperBridgeSettings.to_chain if isinstance(
        SuperBridgeSettings.to_chain, str) else random.choice(SuperBridgeSettings.to_chain)
    use_percentage = SuperBridgeSettings.use_percentage
    bridge_percentage = SuperBridgeSettings.bridge_percentage

    proxy: Proxy = route.wallet.proxy
    while True:
        try:
            to_chain_account = Account(
                private_key=route.wallet.private_key,
                rpc=chain_mapping[to_chain].rpc,
                proxy=proxy
            )
            to_chain_balance = await to_chain_account.get_wallet_balance(is_native=True)
            if to_chain_balance / 10 ** 18 >= SuperBridgeSettings.min_eth_balance:
                logger.debug(
                    f'В сети {to_chain} уже есть {round((to_chain_balance / 10 ** 18), 5)} ETH. '
                    f'Бридж не требуется.'
                )
                return True
            break
        except Exception as ex:
            if (
                    'proxy' in str(ex).lower() or
                    'http' in str(ex).lower() or
                    'host' in str(ex).lower() or
                    'timeout' in str(ex).lower()
            ):
                logger.debug('Changing proxy...')
                await proxy.change()

    amount = random.uniform(SuperBridgeSettings.amount[0], SuperBridgeSettings.amount[1])

    bridge_class = SuperBridge(
        private_key=route.wallet.private_key,
        proxy=route.wallet.proxy,
        bridge_config=BridgeConfig(
            from_chain=Chain(
                chain_name=from_chain,
                native_token=chain_mapping[from_chain.upper()].native_token,
                rpc=chain_mapping[from_chain.upper()].rpc,
                chain_id=chain_mapping[from_chain.upper()].chain_id
            ),
            to_chain=Chain(
                chain_name=to_chain,
                native_token=chain_mapping[to_chain.upper()].native_token,
                rpc=chain_mapping[to_chain.upper()].rpc,
                chain_id=chain_mapping[to_chain.upper()].chain_id
            ),
            from_token=Token(
                chain_name=from_chain,
                name='ETH',
            ),
            to_token=Token(
                chain_name=to_chain,
                name='ETH',
            ),
            amount=amount,
            use_percentage=use_percentage,
            bridge_percentage=bridge_percentage
        )
    )

    logger.debug(bridge_class)
    bridged = await bridge_class.bridge()
    if bridged:
        return True
