from dataclasses import dataclass
from typing import Optional


class SimpleNamespace:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __repr__(self):
        keys = " ".join(f"{k}={v!r}" for k, v in self.__dict__.items())
        return f"SimpleNamespace({keys})"

    def __eq__(self, other):
        return self.__dict__ == getattr(other, "__dict__", {})


@dataclass
class GalxeUser:
    id: Optional[str]
    username: Optional[str]
    avatar: Optional[str]
    address: Optional[str]
    evm_address_secondary: Optional[str]
    has_email: bool
    solana_address: Optional[str]
    aptos_address: Optional[str]
    sei_address: Optional[str]
    injective_address: Optional[str]
    flow_address: Optional[str]
    starknet_address: Optional[str]
    bitcoin_address: Optional[str]
    sui_address: Optional[str]
    stacks_address: Optional[str]
    has_evm_address: bool
    has_solana_address: bool
    has_aptos_address: bool
    has_injective_address: bool
    has_flow_address: bool
    has_starknet_address: bool
    has_bitcoin_address: bool
    has_sui_address: bool
    has_stacks_address: bool
    has_twitter: bool
    has_github: bool
    has_discord: bool
    has_telegram: bool
    has_worldcoin: bool
    display_email: bool
    display_twitter: bool
    display_github: bool
    display_discord: bool
    display_telegram: bool
    display_worldcoin: bool
    display_name_pref: Optional[str]
    email: Optional[str]
    twitter_user_id: Optional[str]
    twitter_user_name: Optional[str]
    github_user_id: Optional[str]
    github_user_name: Optional[str]
    discord_user_id: Optional[str]
    discord_user_name: Optional[str]
    telegram_user_id: Optional[str]
    telegram_user_name: Optional[str]
    worldcoin_id: Optional[str]
    enable_email_subs: bool
    subscriptions: list[str]
    is_whitelisted: bool
    is_invited: bool
    is_admin: bool
    access_token: Optional[str]

    @classmethod
    def from_dict(cls, data: dict) -> "GalxeUser":
        return cls(
            id=data.get("id"),
            username=data.get("username"),
            avatar=data.get("avatar"),
            address=data.get("address"),
            evm_address_secondary=data.get("evmAddressSecondary"),
            has_email=data.get("hasEmail", False),
            solana_address=data.get("solanaAddress"),
            aptos_address=data.get("aptosAddress"),
            sei_address=data.get("seiAddress"),
            injective_address=data.get("injectiveAddress"),
            flow_address=data.get("flowAddress"),
            starknet_address=data.get("starknetAddress"),
            bitcoin_address=data.get("bitcoinAddress"),
            sui_address=data.get("suiAddress"),
            stacks_address=data.get("stacksAddress"),
            has_evm_address=data.get("hasEvmAddress", False),
            has_solana_address=data.get("hasSolanaAddress", False),
            has_aptos_address=data.get("hasAptosAddress", False),
            has_injective_address=data.get("hasInjectiveAddress", False),
            has_flow_address=data.get("hasFlowAddress", False),
            has_starknet_address=data.get("hasStarknetAddress", False),
            has_bitcoin_address=data.get("hasBitcoinAddress", False),
            has_sui_address=data.get("hasSuiAddress", False),
            has_stacks_address=data.get("hasStacksAddress", False),
            has_twitter=data.get("hasTwitter", False),
            has_github=data.get("hasGithub", False),
            has_discord=data.get("hasDiscord", False),
            has_telegram=data.get("hasTelegram", False),
            has_worldcoin=data.get("hasWorldcoin", False),
            display_email=data.get("displayEmail", False),
            display_twitter=data.get("displayTwitter", False),
            display_github=data.get("displayGithub", False),
            display_discord=data.get("displayDiscord", False),
            display_telegram=data.get("displayTelegram", False),
            display_worldcoin=data.get("displayWorldcoin", False),
            display_name_pref=data.get("displayNamePref"),
            email=data.get("email"),
            twitter_user_id=data.get("twitterUserID"),
            twitter_user_name=data.get("twitterUserName"),
            github_user_id=data.get("githubUserID"),
            github_user_name=data.get("githubUserName"),
            discord_user_id=data.get("discordUserID"),
            discord_user_name=data.get("discordUserName"),
            telegram_user_id=data.get("telegramUserID"),
            telegram_user_name=data.get("telegramUserName"),
            worldcoin_id=data.get("worldcoinID"),
            enable_email_subs=data.get("enableEmailSubs", False),
            subscriptions=data.get("subscriptions", []),
            is_whitelisted=data.get("isWhitelisted", False),
            is_invited=data.get("isInvited", False),
            is_admin=data.get("isAdmin", False),
            access_token=data.get("accessToken"),
        )
