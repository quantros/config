DISCORD_AUTH_URL = 'https://discord.com/api/v9/oauth2/authorize'
GALXE_DISCORD_CLIENT_ID = '947863296789323776'

REQUEST_URL = 'https://graphigo.prd.galaxy.eco/query'