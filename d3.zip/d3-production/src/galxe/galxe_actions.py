import json
import random
from asyncio import sleep
from datetime import datetime, timedelta
import string
from typing import Dict, Any, Optional
from urllib.parse import parse_qs, urlparse

import twitter.errors
from loguru import logger

from config import RETRIES, PAUSE_BETWEEN_RETRIES, PAUSE_BETWEEN_MODULES
from src.d3_client.onchain_client import OnchainClient
from src.galxe.campaigns.types import CampaignData
from src.galxe.data.constants import GALXE_DISCORD_CLIENT_ID, DISCORD_AUTH_URL, REQUEST_URL
from src.galxe.types import GalxeUser, SimpleNamespace
from src.galxe.utils import random_string_for_entropy
from src.utils.cherry_solver.client import CherrySolver
from src.utils.common.wrappers.decorators import retry
from src.utils.data.chains import BASE
from src.utils.imap_client.imap import AsyncEmailChecker
from src.utils.proxy_manager import Proxy
from src.utils.request_client.curl_cffi_client import CurlCffiClient
from src.utils.user.account import Account
from src.utils.user.social.discord.discord_client import DiscordClient
from src.utils.user.social.twitter.twitter_client import TwitterClient

VERIFY_TRIES = 4
MAX_TRIES = 4


class GalxeClient(Account, CurlCffiClient):
    # noinspection PyMissingConstructor
    def __init__(
            self,
            private_key: str,
            proxy: Proxy | None,
            twitter_token: str | None = None,
            discord_token: str | None = None,
            email_login: str | None = None,
            email_password: str | None = None,
    ):
        self._twitter_client: Optional[TwitterClient] = None
        self._discord_client: Optional[DiscordClient] = None
        self._captcha_solver: Optional[CherrySolver] = None
        self._email_client: Optional[AsyncEmailChecker] = None

        self.private_key = private_key
        self.twitter_token = twitter_token
        self.discord_token = discord_token
        self.email_login = email_login
        self.email_password = email_password

        self.proxy = proxy
        if proxy:
            self.proxy.attach_client(self)
        self.reinitialize_proxy_clients()

        self.galxe_token = None
        self.galxe_headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "content-type": "application/json",
            "origin": "https://galxe.com",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
        }
        self.galxe_user: Optional[GalxeUser] = None

    def reinitialize_proxy_clients(self):
        Account.__init__(self, private_key=self.private_key, proxy=self.proxy)
        CurlCffiClient.__init__(self, proxy=self.proxy)

        self._twitter_client = TwitterClient(auth_token=self.twitter_token, proxy=self.proxy)
        self._discord_client = DiscordClient(auth_token=self.discord_token, proxy=self.proxy)
        self._captcha_solver = CherrySolver(session=self.session, proxy=self.proxy, verbose=False)
        self._email_client = AsyncEmailChecker(email=self.email_login, password=self.email_password)

    # ------------------------------- Auth ---------------------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def check_if_account_exists(self) -> bool:
        json_data = {
            "operationName": "GalxeIDExist",
            "variables": {"schema": f"EVM:{self.wallet_address}"},
            "query": "query GalxeIDExist($schema: String!) {\n  galxeIdExist(schema: $schema)\n}",
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json["data"]["galxeIdExist"]

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def sign_in(self) -> bool:
        exp_time = (datetime.utcnow() + timedelta(days=7)).isoformat()[:-3] + "Z"
        iss_time = datetime.utcnow().isoformat()[:-3] + "Z"
        msg = (
            "galxe.com wants you to sign in with your Ethereum account:\n"
            f"{self.wallet_address}\n\n"
            "Sign in with Ethereum to the app.\n\n"
            "URI: https://galxe.com\n"
            "Version: 1\n"
            "Chain ID: 1\n"
            f"Nonce: {random_string_for_entropy(96)}\n"
            f"Issued At: {iss_time}\n"
            f"Expiration Time: {exp_time}"
        )
        signature = self.get_signature(msg)
        json_data = {
            "operationName": "SignIn",
            "variables": {
                "input": {
                    "address": self.wallet_address,
                    "addressType": "EVM",
                    "message": msg,
                    "signature": signature,
                }
            },
            "query": "mutation SignIn($input: Auth) {\n  signin(input: $input)\n}",
        }
        response_json, status = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        if status == 200:
            self.galxe_token = response_json["data"]["signin"]
            self.galxe_headers.update({"Authorization": self.galxe_token})
            logger.success(f"[{self.wallet_address}] | [GALXE] | Token grabbed")
            return True
        return False

    @staticmethod
    def _generate_username() -> str:
        allowed = string.ascii_letters + string.digits
        return "".join(random.choice(allowed) for _ in range(random.randint(5, 9)))

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def create_galxe_account(self) -> None:
        username = self._generate_username()
        json_data = {
            "operationName": "CreateNewAccount",
            "variables": {
                "input": {"schema": f"EVM:{self.wallet_address}", "socialUsername": username, "username": username}
            },
            "query": "mutation CreateNewAccount($input: CreateNewAccount!) {\n  createNewAccount(input: $input)\n}",
        }
        _, status = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        if status == 200:
            logger.success(f"[{self.wallet_address}] | [GALXE] | Username set: {username}")

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _get_user_info(self) -> Dict[str, Any]:
        json_data = {
            "operationName": "BasicUserInfo",
            "variables": {"address": f"EVM:{self.wallet_address}"},
            "query": (
                "query BasicUserInfo($address: String!) {\n  addressInfo(address: $address) {\n    id\n    username\n    hasEmail\n    hasTwitter\n    hasDiscord\n    email\n    twitterUserName\n    discordUserID\n    discordUserName\n    __typename\n  }\n}"
            ),
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json["data"]["addressInfo"]

    # -------------------------- Social linking ----------------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def connect_twitter(self) -> Optional[bool]:
        info = await self._get_user_info()
        galxe_id = info["id"]
        try:
            tweet_id, username = await self._twitter_client.post_for_binding(galxe_id)
        except twitter.errors.NotFound:
            logger.error("Tweet failed. Try another token.")
            return None
        if not tweet_id:
            logger.error(f"[{self.wallet_address}] | [GALXE] | Twitter bind failed")
            return False

        json_data = {
            "operationName": "VerifyTwitterAccount",
            "variables": {
                "input": {
                    "address": f"EVM:{self.wallet_address}",
                    "tweetURL": f"https://twitter.com/{username}/status/{tweet_id}",
                }
            },
            "query": (
                "mutation VerifyTwitterAccount($input: VerifyTwitterAccountInput!) {\n  verifyTwitterAccount(input: $input) {\n    address\n    twitterUserID\n    twitterUserName\n    __typename\n  }\n}\n"
            ),
        }
        response_json, status = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        if status == 200 and response_json["data"]["verifyTwitterAccount"]["twitterUserName"] == username:
            logger.success(f"[{self.wallet_address}] | [GALXE] | Twitter connected")
            return True
        logger.error(f"[{self.wallet_address}] | [GALXE] | Twitter bind failed")
        return False

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _get_social_auth_url(self) -> Optional[str]:
        json_data = {
            "operationName": "getSocialAuthUrl",
            "variables": {"schema": f"EVM:{self.wallet_address}", "type": "DISCORD"},
            "query": (
                "query getSocialAuthUrl($schema: String!, $type: SocialAccountType!, $captchaInput: CaptchaInput) {\n"
                "  getSocialAuthUrl(schema: $schema, type: $type, captchaInput: $captchaInput)\n}"
            ),
        }
        response_json, status = await self.make_request("POST", REQUEST_URL, json=json_data, headers=self.galxe_headers)
        if status == 200:
            return response_json["data"]["getSocialAuthUrl"]

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def check_discord_account(self, state, token):
        json_data = {
            "operationName": "checkDiscordAccount",
            "query": (
                "mutation checkDiscordAccount($input: VerifyDiscordAccountInput!) {\n  checkDiscordAccount(input: $input) {\n    address\n    discordUserID\n    __typename\n  }\n}"
            ),
            "variables": {"input": {"address": f"EVM:{self.wallet_address}", "state": state, "token": token}},
        }
        await self.session.request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def verify_discord_account(self, state, token):
        json_data = {
            "operationName": "VerifyDiscord",
            "query": (
                "mutation VerifyDiscord($input: VerifyDiscordAccountInput!) {\n  verifyDiscordAccount(input: $input) {\n    address\n    discordUserID\n"
                "    discordUserName\n    __typename\n  }\n}"
            ),
            "variables": {"input": {"address": f"EVM:{self.wallet_address}", "state": state, "token": token}},
        }
        response = await self.session.request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return not bool(response.json().get("errors", []))

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _connect_discord(self):
        discord_auth_link = await self._get_social_auth_url()
        state = (parse_qs(urlparse(discord_auth_link).query).get("state"))[0]
        params = {
            "client_id": GALXE_DISCORD_CLIENT_ID,
            "response_type": "code",
            "redirect_uri": "https://galxe.com",
            "scope": "identify guilds guilds.members.read",
            "state": f"Discord_Auth,EVM:{self.wallet_address},false,{state}",
        }
        json_data = {"permissions": "0", "authorize": True, "integration_type": 0}
        response_json, _ = await self.make_request(
            "POST", DISCORD_AUTH_URL, params=params, json=json_data, headers={"Authorization": self.discord_token}
        )
        location_url = response_json.get("location")
        if not location_url:
            raise RuntimeError(f"Discord authorize returned no location: {response_json}")
        token = (parse_qs(urlparse(location_url).query).get("code"))[0]
        await self.check_discord_account(state, token)
        return await self.verify_discord_account(state, token)

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _send_verification_code(self):
        i = 0
        while i < 10:
            i += 1
            captcha = await self._captcha_solver.solve_captcha(
                captcha_name='geetest',
                data_for_solver={
                    'websiteURL': 'https://app.galxe.com/'
                }
            )
            json_data = {
                "operationName": "SendVerifyCode",
                "variables": {
                    "input": {
                        "address": f"EVM:{self.wallet_address}",
                        "email": self.email_login,
                        "captcha": {
                            "lotNumber": captcha["lot_number"],
                            "captchaOutput": captcha["captcha_output"],
                            "passToken": captcha["pass_token"],
                            "genTime": captcha["gen_time"],
                            "encryptedData": "",
                        },
                    }
                },
                "query": (
                    "mutation SendVerifyCode($input: SendVerificationEmailInput!) {\n  sendVerificationCode(input: $input) {\n"
                    "    code\n    message\n    __typename\n  }\n}"
                ),
            }
            response_json, status = await self.make_request(
                "POST", REQUEST_URL, json=json_data, headers=self.galxe_headers
            )
            if status == 200 and "recaptcha" not in json.dumps(response_json):
                logger.success(f"[{self.wallet_address}] | Verification code sent")
                return True
            errors = response_json.get('errors', [])
            if not errors:
                logger.error(f'[{self.wallet_address}] | Unknown error while sending email code | {response_json}')
                return None
            for error in errors:
                if error['message'] == 'Fail to verify recaptcha':
                    logger.warning(f'[{self.wallet_address}] | IP limit. Changing proxy...')
                    await self.proxy.change()
                    await sleep(10)

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _verify_email_code(self, code: str):
        json_data = {
            "operationName": "UpdateEmail",
            "query": (
                "mutation UpdateEmail($input: UpdateEmailInput!) {\n  updateEmail(input: $input) {\n    code\n    message\n    __typename\n  }\n}\n"
            ),
            "variables": {
                "input": {
                    "address": f"EVM:{self.wallet_address}",
                    "email": self.email_login,
                    "verificationCode": code,
                }
            },
        }
        await self.make_request("POST", REQUEST_URL, json=json_data, headers=self.galxe_headers)

    async def connect_email(self):
        if not await self._send_verification_code():
            return None
        await sleep(10)
        code = await self._email_client.check_email_for_verification_link(pattern=r"(?<!\d)\d{6}(?!\d)")
        if not code:
            return None
        await self._verify_email_code(code)
        return True

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def prepare_account(self) -> GalxeUser | bool:
        if not await self.sign_in():
            return False
        if not await self.check_if_account_exists():
            await self.create_galxe_account()
        info = await self._get_user_info()
        if not info.get("hasTwitter"):
            logger.debug(f"[{self.wallet_address}] | [GALXE] | Connecting twitter...")
            if not await self.connect_twitter():
                return False
        if not info.get("hasDiscord"):
            logger.debug(f"[{self.wallet_address}] | [GALXE] | Connecting discord...")
            if await self._connect_discord():
                logger.success(f"[{self.wallet_address}] | [GALXE] | Discord connected")
        if not info.get("hasEmail") and self.email_login:
            logger.debug(f"[{self.wallet_address}] | [GALXE] | Linking email...")
            if await self.connect_email():
                logger.success(f"[{self.wallet_address}] | Email linked")
        return GalxeUser.from_dict(await self._get_user_info())

    # ------------------------------ Campaigns -----------------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def get_campaign_info(self, campaign_id: str) -> CampaignData:
        json_data = {
            "operationName": "CampaignDetailAll",
            'query': 'query CampaignDetailAll($id: ID!, $address: String!, $withAddress: Boolean!) {\n  campaign(id: $id) {\n    ...CampaignForSiblingSlide\n    coHostSpaces {\n      ...SpaceDetail\n      isAdmin(address: $address) @include(if: $withAddress)\n      isFollowing @include(if: $withAddress)\n      followersCount\n      categories\n      __typename\n    }\n    bannerUrl\n    ...CampaignDetailFrag\n    userParticipants(address: $address, first: 1) @include(if: $withAddress) {\n      list {\n        status\n        premintTo\n        __typename\n      }\n      __typename\n    }\n    space {\n      ...SpaceDetail\n      isAdmin(address: $address) @include(if: $withAddress)\n      isFollowing @include(if: $withAddress)\n      followersCount\n      categories\n      __typename\n    }\n    isBookmarked(address: $address) @include(if: $withAddress)\n    inWatchList\n    claimedLoyaltyPoints(address: $address) @include(if: $withAddress)\n    parentCampaign {\n      id\n      isSequencial\n      thumbnail\n      __typename\n    }\n    isSequencial\n    numNFTMinted\n    childrenCampaigns {\n      ...ChildrenCampaignsForCampaignDetailAll\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CampaignDetailFrag on Campaign {\n  id\n  ...CampaignMedia\n  ...CampaignForgePage\n  ...CampaignForCampaignParticipantsBox\n  name\n  numberID\n  type\n  inWatchList\n  cap\n  info\n  useCred\n  smartbalancePreCheck(mintCount: 1)\n  smartbalanceDeposited\n  formula\n  status\n  seoImage\n  creator\n  tags\n  thumbnail\n  gasType\n  isPrivate\n  createdAt\n  requirementInfo\n  description\n  enableWhitelist\n  chain\n  startTime\n  endTime\n  requireEmail\n  requireUsername\n  blacklistCountryCodes\n  whitelistRegions\n  rewardType\n  distributionType\n  rewardName\n  claimEndTime\n  loyaltyPoints\n  tokenRewardContract {\n    id\n    address\n    chain\n    __typename\n  }\n  tokenReward {\n    userTokenAmount\n    tokenAddress\n    depositedTokenAmount\n    tokenRewardId\n    tokenDecimal\n    tokenLogo\n    tokenSymbol\n    __typename\n  }\n  nftHolderSnapshot {\n    holderSnapshotBlock\n    __typename\n  }\n  spaceStation {\n    id\n    address\n    chain\n    __typename\n  }\n  ...WhitelistInfoFrag\n  ...WhitelistSubgraphFrag\n  gamification {\n    ...GamificationDetailFrag\n    __typename\n  }\n  creds {\n    id\n    name\n    type\n    credType\n    credSource\n    referenceLink\n    description\n    lastUpdate\n    lastSync\n    syncStatus\n    credContractNFTHolder {\n      timestamp\n      __typename\n    }\n    chain\n    eligible(address: $address, campaignId: $id)\n    subgraph {\n      endpoint\n      query\n      expression\n      __typename\n    }\n    dimensionConfig\n    value {\n      gitcoinPassport {\n        score\n        lastScoreTimestamp\n        __typename\n      }\n      __typename\n    }\n    commonInfo {\n      participateEndTime\n      modificationInfo\n      __typename\n    }\n    __typename\n  }\n  credentialGroups(address: $address) {\n    ...CredentialGroupForAddress\n    __typename\n  }\n  rewardInfo {\n    discordRole {\n      guildId\n      guildName\n      roleId\n      roleName\n      inviteLink\n      __typename\n    }\n    premint {\n      startTime\n      endTime\n      chain\n      price\n      totalSupply\n      contractAddress\n      banner\n      __typename\n    }\n    loyaltyPoints {\n      points\n      __typename\n    }\n    loyaltyPointsMysteryBox {\n      points\n      weight\n      __typename\n    }\n    __typename\n  }\n  participants {\n    participantsCount\n    bountyWinnersCount\n    __typename\n  }\n  taskConfig(address: $address) {\n    participateCondition {\n      conditions {\n        ...ExpressionEntity\n        __typename\n      }\n      conditionalFormula\n      eligible\n      __typename\n    }\n    rewardConfigs {\n      id\n      conditions {\n        ...ExpressionEntity\n        __typename\n      }\n      conditionalFormula\n      description\n      rewards {\n        ...ExpressionReward\n        __typename\n      }\n      eligible\n      rewardAttrVals {\n        attrName\n        attrTitle\n        attrVal\n        __typename\n      }\n      __typename\n    }\n    referralConfig {\n      id\n      conditions {\n        ...ExpressionEntity\n        __typename\n      }\n      conditionalFormula\n      description\n      rewards {\n        ...ExpressionReward\n        __typename\n      }\n      eligible\n      rewardAttrVals {\n        attrName\n        attrTitle\n        attrVal\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  referralCode(address: $address)\n  recurringType\n  latestRecurringTime\n  nftTemplates {\n    id\n    image\n    treasureBack\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignMedia on Campaign {\n  thumbnail\n  rewardName\n  type\n  gamification {\n    id\n    type\n    __typename\n  }\n  __typename\n}\n\nfragment CredentialGroupForAddress on CredentialGroup {\n  id\n  description\n  credentials {\n    ...CredForAddressWithoutMetadata\n    __typename\n  }\n  conditionRelation\n  conditions {\n    expression\n    eligible\n    ...CredentialGroupConditionForVerifyButton\n    __typename\n  }\n  rewards {\n    expression\n    eligible\n    rewardCount\n    rewardType\n    __typename\n  }\n  rewardAttrVals {\n    attrName\n    attrTitle\n    attrVal\n    __typename\n  }\n  claimedLoyaltyPoints\n  __typename\n}\n\nfragment CredForAddressWithoutMetadata on Cred {\n  id\n  name\n  type\n  credType\n  credSource\n  referenceLink\n  description\n  lastUpdate\n  lastSync\n  syncStatus\n  credContractNFTHolder {\n    timestamp\n    __typename\n  }\n  chain\n  eligible(address: $address)\n  subgraph {\n    endpoint\n    query\n    expression\n    __typename\n  }\n  dimensionConfig\n  value {\n    gitcoinPassport {\n      score\n      lastScoreTimestamp\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CredentialGroupConditionForVerifyButton on CredentialGroupCondition {\n  expression\n  eligibleAddress\n  __typename\n}\n\nfragment WhitelistInfoFrag on Campaign {\n  id\n  whitelistInfo(address: $address) {\n    address\n    maxCount\n    usedCount\n    claimedLoyaltyPoints\n    currentPeriodClaimedLoyaltyPoints\n    currentPeriodMaxLoyaltyPoints\n    __typename\n  }\n  __typename\n}\n\nfragment WhitelistSubgraphFrag on Campaign {\n  id\n  whitelistSubgraph {\n    query\n    endpoint\n    expression\n    variable\n    __typename\n  }\n  __typename\n}\n\nfragment GamificationDetailFrag on Gamification {\n  id\n  type\n  nfts {\n    nft {\n      id\n      animationURL\n      category\n      powah\n      image\n      name\n      treasureBack\n      nftCore {\n        ...NftCoreInfoFrag\n        __typename\n      }\n      traits {\n        name\n        value\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n    forgeConfig {\n    minNFTCount\n    maxNFTCount\n    requiredNFTs {\n      nft {\n        category\n        powah\n        image\n        name\n        nftCore {\n          capable\n          contractAddress\n          __typename\n        }\n        __typename\n      }\n      count\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment NftCoreInfoFrag on NFTCore {\n  id\n  capable\n  chain\n  contractAddress\n  name\n  symbol\n  dao {\n    id\n    name\n    logo\n    alias\n    __typename\n  }\n  __typename\n}\n\nfragment ExpressionEntity on ExprEntity {\n  cred {\n    id\n    name\n    type\n    credType\n    credSource\n    dimensionConfig\n    referenceLink\n    description\n    lastUpdate\n    lastSync\n    chain\n    eligible(address: $address)\n    metadata {\n      visitLink {\n        link\n        __typename\n      }\n      twitter {\n        isAuthentic\n        __typename\n      }\n      __typename\n    }\n    commonInfo {\n      participateEndTime\n      modificationInfo\n      __typename\n    }\n    __typename\n  }\n  attrs {\n    attrName\n    operatorSymbol\n    targetValue\n    __typename\n  }\n  attrFormula\n  eligible\n  eligibleAddress\n  __typename\n}\n\nfragment ExpressionReward on ExprReward {\n  arithmetics {\n    ...ExpressionEntity\n    __typename\n  }\n  arithmeticFormula\n  rewardType\n  rewardCount\n  rewardVal\n  __typename\n}\n\nfragment CampaignForgePage on Campaign {\n  id\n  numberID\n  chain\n  spaceStation {\n    address\n    __typename\n  }\n  gamification {\n    forgeConfig {\n      maxNFTCount\n      minNFTCount\n      requiredNFTs {\n        nft {\n          category\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignForCampaignParticipantsBox on Campaign {\n  ...CampaignForParticipantsDialog\n  id\n  chain\n  space {\n    id\n    isAdmin(address: $address)\n    __typename\n  }\n  participants {\n    participants(first: 10, after: \"-1\", download: false) {\n      list {\n        address {\n          id\n          avatar\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    participantsCount\n    bountyWinners(first: 10, after: \"-1\", download: false) {\n      list {\n        createdTime\n        address {\n          id\n          avatar\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    bountyWinnersCount\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignForParticipantsDialog on Campaign {\n  id\n  name\n  type\n  rewardType\n  chain\n  nftHolderSnapshot {\n    holderSnapshotBlock\n    __typename\n  }\n  space {\n    isAdmin(address: $address)\n    __typename\n  }\n  rewardInfo {\n    discordRole {\n      guildName\n      roleName\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment SpaceDetail on Space {\n  id\n  name\n  info\n  thumbnail\n  alias\n  status\n  links\n  isVerified\n  discordGuildID\n  followersCount\n  nftCores(input: {first: 1}) {\n    list {\n      id\n      marketLink\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment ChildrenCampaignsForCampaignDetailAll on Campaign {\n  space {\n    ...SpaceDetail\n    isAdmin(address: $address) @include(if: $withAddress)\n    isFollowing @include(if: $withAddress)\n    followersCount\n    categories\n    __typename\n  }\n  ...CampaignDetailFrag\n  claimedLoyaltyPoints(address: $address) @include(if: $withAddress)\n  userParticipants(address: $address, first: 1) @include(if: $withAddress) {\n    list {\n      status\n      __typename\n    }\n    __typename\n  }\n  parentCampaign {\n    id\n    isSequencial\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignForSiblingSlide on Campaign {\n  id\n  space {\n    id\n    alias\n    __typename\n  }\n  parentCampaign {\n    id\n    thumbnail\n    isSequencial\n    childrenCampaigns {\n      id\n      ...CampaignForGetImage\n      ...CampaignForCheckFinish\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignForCheckFinish on Campaign {\n  claimedLoyaltyPoints(address: $address)\n  whitelistInfo(address: $address) {\n    usedCount\n    __typename\n  }\n  __typename\n}\n\nfragment CampaignForGetImage on Campaign {\n  ...GetImageCommon\n  nftTemplates {\n    image\n    __typename\n  }\n  __typename\n}\n\nfragment GetImageCommon on Campaign {\n  ...CampaignForTokenObject\n  id\n  type\n  thumbnail\n  __typename\n}\n\nfragment CampaignForTokenObject on Campaign {\n  tokenReward {\n    tokenAddress\n    tokenSymbol\n    tokenDecimal\n    tokenLogo\n    __typename\n  }\n  tokenRewardContract {\n    id\n    chain\n    __typename\n  }\n  __typename\n}\n',
            "variables": {"address": self.wallet_address, "id": campaign_id, "withAddress": True},
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return CampaignData.from_dict(response_json["data"]["campaign"])

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def verify_credentials(self, cred_ids: list[str]):
        json_data = {
            "operationName": "VerifyCredentials",
            "query": "mutation VerifyCredentials($input: VerifyCredentialsInput!) {\n  verifyCredentials(input: $input)\n}\n",
            "variables": {"input": {"address": self.wallet_address, "credIds": cred_ids}},
        }
        await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)

    # ---- low-level sync helpers ----

    def _sync_options_base(self, cred_id: str) -> dict:
        return {"credId": cred_id, "address": f"EVM:{self.wallet_address}"}

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def sync_credential_value(self, credential_id: str):
        json_data = {
            "operationName": "SyncCredentialValue",
            "variables": {"input": {"syncOptions": self._sync_options_base(credential_id)}},
            'query': 'mutation SyncCredentialValue($input: SyncCredentialValueInput!) {\n  syncCredentialValue(input: $input) {\n    value {\n      address\n      spaceUsers {\n        follow\n        points\n        participations\n        __typename\n      }\n      campaignReferral {\n        count\n        __typename\n      }\n      gitcoinPassport {\n        score\n        lastScoreTimestamp\n        __typename\n      }\n      walletBalance {\n        balance\n        __typename\n      }\n      multiDimension {\n        value\n        __typename\n      }\n      allow\n      survey {\n        answers\n        __typename\n      }\n      quiz {\n        allow\n        correct\n        __typename\n      }\n      __typename\n    }\n    message\n    __typename\n  }\n}\n',
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def sync_credential_value_with_options(self, sync_options: dict):
        json_data = {
            "operationName": "SyncCredentialValue",
            "variables": {
                "input": {
                    "syncOptions": sync_options
                }
            },
            'query': 'mutation SyncCredentialValue($input: SyncCredentialValueInput!) {\n  syncCredentialValue(input: $input) {\n    value {\n      address\n      spaceUsers {\n        follow\n        points\n        participations\n        __typename\n      }\n      campaignReferral {\n        count\n        __typename\n      }\n      gitcoinPassport {\n        score\n        lastScoreTimestamp\n        __typename\n      }\n      walletBalance {\n        balance\n        __typename\n      }\n      multiDimension {\n        value\n        __typename\n      }\n      allow\n      survey {\n        answers\n        __typename\n      }\n      quiz {\n        allow\n        correct\n        __typename\n      }\n      __typename\n    }\n    message\n    __typename\n  }\n}\n',
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def sync_evaluate_credential_value(self, eval_expr: dict, sync_options: dict):
        json_data = {
            "operationName": "syncEvaluateCredentialValue",
            "query": (
                "mutation syncEvaluateCredentialValue($input: SyncEvaluateCredentialValueInput!) {\n"
                "  syncEvaluateCredentialValue(input: $input) { result value { allow quiz { allow correct __typename } __typename } message __typename }\n}"
            ),
            "variables": {"input": {"evalExpr": eval_expr, "syncOptions": sync_options}},
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def add_typed_credential_items(self, campaign_id: str, credential_id: str, captcha_data: dict):
        json_data = {
            "operationName": "AddTypedCredentialItems",
            "variables": {
                "input": {
                    "credId": credential_id,
                    "campaignId": campaign_id,
                    "operation": "APPEND",
                    "items": [f"EVM:{self.wallet_address}"],
                    "captcha": {
                        "lotNumber": captcha_data["lot_number"],
                        "captchaOutput": captcha_data["captcha_output"],
                        "passToken": captcha_data["pass_token"],
                        "genTime": captcha_data["gen_time"],
                    },
                }
            },
            "query": "mutation AddTypedCredentialItems($input: MutateTypedCredItemInput!) {\n  typedCredentialItems(input: $input) { id __typename }\n}",
        }
        return await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)

    # ---------------------------- Quiz / Survey ---------------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def read_survey(self, credential_id: str) -> list[dict]:
        json_data = {
            "operationName": "readSurvey",
            'query': 'query readSurvey($id: ID!) {\n  credential(id: $id) {\n    metadata {\n      survey {\n        ...SurveyCredMetadataFrag\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment SurveyCredMetadataFrag on SurveyCredMetadata {\n  surveies {\n    title\n    type\n    items {\n      value\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n',
            "variables": {"id": credential_id},
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json['data']['credential']['metadata']['survey']['surveies']

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def submit_survey_auto(self, cred) -> bool:
        try:
            questions = await self.read_survey(cred.id)
            answers: list[str] = []
            for q in questions:
                items = [i.get("value") for i in (q.get("items") or [])]
                if items:
                    answers.append(str(items[0]))
                else:
                    answers.append("")
            sync_options = self._sync_options_base(cred.id)
            payload = {"survey": {"answers": answers}}
            resp = await self.sync_credential_value_with_options(sync_options | payload)
            scv = (resp or {}).get("data", {}).get("syncCredentialValue")
            return bool(scv and scv.get("value", {}).get("allow"))
        except Exception as e:
            logger.warning(f"[{self.wallet_address}] | survey submit failed: {e}")
            return False

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def solve_quiz_auto(self, cred) -> bool:
        max_options = 6
        for idx in range(max_options):
            try:
                sync_options = self._sync_options_base(cred.id)
                payload = {"quiz": {"answers": [str(idx)]}}
                resp = await self.sync_credential_value_with_options(sync_options | payload)
                scv = (resp or {}).get("data", {}).get("syncCredentialValue")
                if scv and scv.get("value", {}).get("allow"):
                    return True
            except Exception:
                pass
        return False

    # ---------------------- Routing helpers -----------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def classify_cred(self, cred: dict) -> str:
        try:
            cs = (cred.get("credSource") or "").upper()
            ct = (cred.get("credType") or "").upper()
            t = (cred.get("type") or "").upper()
            meta = cred.get("metadata") or {}
            if cs == 'WATCH_YOUTUBE':
                return "YOUTUBE"
            if cs == 'SURVEY':
                return "SURVEY"
            if cs == 'VISIT_LINK':
                return "VISIT"
            if ct == 'DISCORD':
                return 'DISCORD'
            if cs == 'GRAPHQL':
                return 'GRAPHQL'
            if cs == 'TWITTER_RT':
                return 'TWITTER_RT'
            if cs == 'TWITTER_LIKE':
                return 'TWITTER_LIKE'
            if (meta.get("visitLink") or {}).get("link"):
                return "VISIT"

            if "TWITTER" in (cs + ct + t) or ("twitter" in meta):
                return "TWITTER"

            if cs == 'QUIZ':
                return "QUIZ"

            if cred.get("subgraph") or cred.get("chain"):
                return "ONCHAIN"
        except Exception:
            pass
        return "GENERIC"

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _perform_twitter(self, campaign_id, cred: dict) -> bool:
        cred_id = cred.get("id")
        eval_expr = cred.get("evalExpr") or cred.get("eval_expr")
        try:
            if eval_expr:
                r = await self.sync_evaluate_credential_value(eval_expr, self._sync_options_base(cred_id))
                scve = (r or {}).get("data", {}).get("syncEvaluateCredentialValue")
                if scve and scve.get("value", {}).get("allow"):
                    return True

            await self.twitter_oauth2_status()
            captcha_data = await self._captcha_solver.solve_captcha(
                captcha_name='geetest',
                data_for_solver={
                    'websiteURL': 'https://app.galxe.com/'
                }
            )
            sync_options = self._sync_options_base(cred_id)
            sync_options.update({
                'twitter': {
                    'campaignID': campaign_id,
                    "captcha": {
                        "lotNumber": captcha_data["lot_number"],
                        "captchaOutput": captcha_data["captcha_output"],
                        "passToken": captcha_data["pass_token"],
                        "genTime": captcha_data["gen_time"],
                    },
                }
            })
            r2 = await self.sync_credential_value_with_options(sync_options)
            scv = (r2 or {}).get("data", {}).get("syncCredentialValue")
            return bool(scv and scv.get("value", {}).get("allow"))
        except Exception as e:
            logger.debug(f"[{self.wallet_address}] | twitter sync failed: {e}")
            return False

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def twitter_oauth2_status(self):
        json_data = {
            'operationName': 'TwitterOauth2Status',
            'query': 'query TwitterOauth2Status {\n  twitterOauth2Status {\n    oauthRateLimited\n    __typename\n  }\n}\n',
            'variables': {},
        }
        await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)

    # ---------------------- High-level participate/claim ------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def prepare_participate(self, campaign_id: str, chain: str):
        captcha = await self._captcha_solver.solve_captcha(
            captcha_name='geetest',
            data_for_solver={
                'websiteURL': 'https://app.galxe.com/'
            }
        )
        json_data = {
            "operationName": "PrepareParticipate",
            "variables": {
                "input": {
                    "signature": "",
                    "campaignID": campaign_id,
                    "address": f"EVM:{self.wallet_address}",
                    "mintCount": 1,
                    "chain": chain,
                    'pointMintAmount': 0,
                    "captcha": {
                        "lotNumber": captcha["lot_number"],
                        "captchaOutput": captcha["captcha_output"],
                        "passToken": captcha["pass_token"],
                        "genTime": captcha["gen_time"],
                    },
                }
            },
            'query': 'mutation PrepareParticipate($input: PrepareParticipateInput!) {\n  prepareParticipate(input: $input) {\n    allow\n    disallowReason\n    signature\n    nonce\n    spaceStationInfo {\n      address\n      chain\n      version\n      __typename\n    }\n    mintFuncInfo {\n      funcName\n      nftCoreAddress\n      verifyIDs\n      powahs\n      cap\n      claimFeeAmount\n      __typename\n    }\n    extLinkResp {\n      success\n      data\n      error\n      __typename\n    }\n    metaTxResp {\n      metaSig2\n      autoTaskUrl\n      metaSpaceAddr\n      forwarderAddr\n      metaTxHash\n      reqQueueing\n      __typename\n    }\n    solanaTxResp {\n      mint\n      updateAuthority\n      explorerUrl\n      signedTx\n      verifyID\n      __typename\n    }\n    aptosTxResp {\n      signatureExpiredAt\n      tokenName\n      __typename\n    }\n    spaceStation\n    airdropRewardCampaignTxResp {\n      airdropID\n      verifyID\n      index\n      account\n      amount\n      proof\n      customReward\n      __typename\n    }\n    tokenRewardCampaignTxResp {\n      signatureExpiredAt\n      verifyID\n      encodeAddress\n      weight\n      claimFeeAmount\n      __typename\n    }\n    loyaltyPointsTxResp {\n      TotalClaimedPoints\n      VerifyIDs\n      loyaltyPointDistributionStation\n      signature\n      disallowReason\n      nonce\n      allow\n      loyaltyPointContract\n      Points\n      reqQueueing\n      claimFeeAmount\n      suiTxResp {\n        galxeTableId\n        __typename\n      }\n      __typename\n    }\n    flowTxResp {\n      Name\n      Description\n      Thumbnail\n      __typename\n    }\n    xrplLinks\n    suiTxResp {\n      packageId\n      tableId\n      nftName\n      campaignId\n      verifyID\n      imgUrl\n      signatureExpiredAt\n      __typename\n    }\n    algorandTxResp {\n      algorandArgs {\n        args\n        __typename\n      }\n      algorandBoxes {\n        boxes\n        __typename\n      }\n      __typename\n    }\n    spaceStationProxyResp {\n      target\n      callData\n      __typename\n    }\n    luckBasedTokenCampaignTxResp {\n      cid\n      dummyId\n      expiredAt\n      claimTo\n      index\n      claimAmount\n      proof\n      claimFeeAmount\n      signature\n      encodeAddress\n      weight\n      __typename\n    }\n    __typename\n  }\n}',
        }
        response_json, _ = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def participate(self, campaign_id: str, chain: str, nonce: int, tx_hash: str, verify_id: str):
        json_data = {
            "operationName": "Participate",
            "query": "mutation Participate($input: ParticipateInput!) {\n  participate(input: $input) { participated __typename }\n}\n",
            "variables": {
                "input": {
                    "address": f"EVM:{self.wallet_address}",
                    "campaignID": campaign_id,
                    "chain": chain,
                    "nonce": nonce,
                    "signature": "",
                    "tx": tx_hash,
                    "verifyIDs": [verify_id],
                }
            },
        }
        response_json, status = await self.make_request("POST", REQUEST_URL, headers=self.galxe_headers, json=json_data)
        return response_json['data']['participate']['participated']

    def _claim_params_from_campaign(self, campaign: CampaignData) -> dict:
        wl = campaign.whitelistInfo or {}
        cur = int(wl.get("currentPeriodClaimedLoyaltyPoints", 0) or 0)
        mx = int(wl.get("currentPeriodMaxLoyaltyPoints", 0) or 0)
        max_count = int(wl.get("maxCount", 0) or 0)
        used = int(wl.get("usedCount", 0) or 0)
        point_mint = max(0, mx - cur)
        mint_cnt = 0 if max_count == -1 else max(0, max_count - used)
        return {"pointMintAmount": point_mint, "mintCount": mint_cnt}

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def claim_campaign(self, campaign_id: str, campaign: CampaignData) -> bool:
        gamification_type = campaign.gamification.type
        chain = "BASE"
        if gamification_type == 'DiscordRole':
            chain = "ETHEREUM"
        prep = await self.prepare_participate(campaign_id, chain)
        if not prep:
            return False

        if gamification_type == 'DiscordRole':
            if prep['data']['prepareParticipate']['allow']:
                logger.success(f'[{self.wallet_address}] | Successfully claimed discord role')
                return True

        data = prep['data']['prepareParticipate']

        if not data['allow']:
            reason = prep['data']['prepareParticipate']['disallowReason']
            logger.error(
                f'[{self.wallet_address}] | Not allowed to claim campaign {campaign_id}. '
                f'Reason: {reason}.'
            )
            return False

        onchain_client = OnchainClient(
            private_key=self.private_key, proxy=self.proxy, session=self.session, rpc=BASE.rpc
        )
        tx_hash = await onchain_client.send_galxe_claim_tx(transaction_data=data)
        if not tx_hash:
            return False

        return await self.participate(
            campaign_id,
            data['spaceStationInfo']['chain'],
            int(data['nonce']),
            tx_hash,
            data['mintFuncInfo']['verifyIDs'][0],
        )

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def add_typed_credential(self, campaign_id: str, cred_id: str):
        i = 0
        while i < 10:
            i += 1
            captcha_data = await self._captcha_solver.solve_captcha(
                captcha_name='geetest',
                data_for_solver={
                    'websiteURL': 'https://app.galxe.com/'
                }
            )
            r, _ = await self.add_typed_credential_items(campaign_id, cred_id, captcha_data)
            errors = r.get('errors', [])
            if errors:
                for error in errors:
                    if error['message'] == 'ip limit':
                        logger.warning(f'[{self.wallet_address}] | IP limit. Changing proxy...')
                        await self.proxy.change()
                        await sleep(35)
            else:
                logger.success(f'[{self.wallet_address}] | Successfully added credential item!')
                break

    # ------------------------------ Completion ----------------------------

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def _complete_condition_group(self, campaign_id: str, cred_group_dict: dict) -> bool:
        try_again = False
        conditions = cred_group_dict.get("conditions") or []
        credentials = cred_group_dict.get("credentials") or []

        for cond, cred in zip(conditions, credentials):
            cred_dict = cred if isinstance(cred, dict) else json.loads(
                json.dumps(cred, default=lambda o: getattr(o, "__dict__", {})))
            eligible = int((cond or {}).get("eligible", 1))
            if eligible:
                logger.success(f'[{self.wallet_address}] | {cred_dict['name']} quest has been already completed!')
                continue

            cred_id = cred_dict.get("id")
            if not cred_id:
                continue

            route = await self.classify_cred(cred_dict)

            if route == "VISIT":
                await self.add_typed_credential(campaign_id, cred_id)
                await sleep(5)
                scv_resp = await self.sync_credential_value(cred_id)
                data = (scv_resp or {}).get("data", {})
                scv = data.get("syncCredentialValue")
                if scv and scv.get("value", {}).get("allow") is True:
                    logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')
                    try_again = False

            elif route == 'YOUTUBE':
                await self.add_typed_credential(campaign_id, cred_id)
                await sleep(5)
                scv_resp = await self.sync_credential_value(cred_id)
                data = (scv_resp or {}).get("data", {})
                scv = data.get("syncCredentialValue")
                if scv and scv.get("value", {}).get("allow") is True:
                    logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')
                    try_again = False
            elif route in ['ONCHAIN', 'GRAPHQL']:
                scv_resp = await self.sync_credential_value(cred_id)
                last_msg = scv_resp['data']['syncCredentialValue']['message']
                if last_msg.startswith('If you have already fulfilled'):
                    logger.success(
                        f'[{self.wallet_address}] | {cred_dict['name']} quest has been submitted. Wait for next update...'
                    )
                    try_again = False

            elif route == "SURVEY":
                await self.submit_survey_auto(SimpleNamespace(id=cred_id))
                logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')

            elif route == "QUIZ":
                await self.solve_quiz_auto(SimpleNamespace(id=cred_id))
                logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')

            elif route == 'DISCORD':
                # await self.add_typed_credential(campaign_id, cred_id)
                await sleep(5)
                scv_resp = await self.sync_credential_value(cred_id)
                data = (scv_resp or {}).get("data", {})
                scv = data.get("syncCredentialValue")
                if scv and scv.get("value", {}).get("allow") is True:
                    logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')
                    try_again = False

            elif route in ["TWITTER", "TWITTER_LIKE", "TWITTER_RT"]:
                await self.add_typed_credential(campaign_id, cred_id)
                completed = await self._perform_twitter(campaign_id, cred_dict)
                if completed:
                    logger.success(f'[{self.wallet_address}] | Successfully completed {cred_dict['name']} quest!')
                    try_again = False

            # ok = await self.handle_credential_with_retries(campaign_id, SimpleNamespace(id=cred_id))
            # if not ok:
            #     try_again = True
            random_pause = random.randint(PAUSE_BETWEEN_MODULES[0], PAUSE_BETWEEN_MODULES[1])
            logger.debug(f'[{self.wallet_address}] | Sleeping {random_pause} seconds before next quest...')
            await sleep(random_pause)
        return try_again

    async def handle_credential_with_retries(self, campaign_id: str, cred, max_retries: int = 4) -> bool:
        cred_id = cred.id
        last_msg = None

        try:
            await self.add_typed_credential(campaign_id, cred_id)
        except Exception:
            pass
        for attempt in range(1, max_retries + 1):
            scv_resp = await self.sync_credential_value(cred_id)
            data = (scv_resp or {}).get("data", {})
            errors = (scv_resp or {}).get("errors", [])
            scv = data.get("syncCredentialValue")
            if scv and scv.get("value", {}).get("allow") is True:
                return True
            msg = scv.get("message") if scv else None
            last_msg = msg or (errors[0].get("message") if errors else None)
            if msg and "visit the link first" in msg:
                await sleep(35 if attempt == 1 else 45)
                continue
            if errors and any("missing survey answers" in (e.get("message") or "") for e in errors):
                if await self.submit_survey_auto(cred):
                    try:
                        resp2 = await self.sync_credential_value_with_options(self._sync_options_base(cred.id))
                        scv2 = (resp2 or {}).get("data", {}).get("syncCredentialValue")
                        if scv2 and scv2.get("value", {}).get("allow"):
                            return True
                    except Exception:
                        pass
                return False
            if errors and any("missing twitter args" in (e.get("message") or "") for e in errors):
                return False
            if errors and any("empty address" in (e.get("message") or "") for e in errors):
                try:
                    await self.add_typed_credential(campaign_id, cred_id)
                except Exception:
                    pass
                await sleep(2)
                continue
            await sleep(8)
            if errors and any("quiz" in (e.get("message") or "").lower() for e in errors):
                return await self.solve_quiz_auto(cred)
        if last_msg:
            logger.debug(f"[{self.wallet_address}] | cred {cred_id} sync exhausted. Last message: {last_msg}")
        return False

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def verify_all_credentials(self, campaign_json: dict) -> bool:
        cred_ids: list[str] = []
        for group in campaign_json.get("credentialGroups", []) or []:
            for cred in group.get("credentials", []) or []:
                if int(cred.get("eligible", 1)) == 0:
                    cred_ids.append(cred.get("id"))
        tc = (campaign_json.get("taskConfig") or {})
        pc = (tc.get("participateCondition") or {})
        for cond in pc.get("conditions", []) or []:
            c = cond.get("cred", {})
            if c.get("id"):
                cred_ids.append(c.get("id"))
        if not cred_ids:
            return False
        try:
            await self.verify_credentials(list(set(cred_ids)))
            await sleep(3)
            return True
        except Exception as e:
            logger.warning(f"[{self.wallet_address}] | verify_all_credentials failed: {e}")
            return False

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def complete_campaign(self, campaign_id: str) -> bool:
        campaign = await self.get_campaign_info(campaign_id)
        cdict = campaign.to_dict() if hasattr(campaign, "to_dict") else json.loads(
            json.dumps(campaign, default=lambda o: getattr(o, "__dict__", str(o))))

        if cdict.get("requireEmail") and self.email_login:
            try:
                await self.connect_email()
            except Exception as e:
                logger.warning(f"[{self.wallet_address}] | campaign requires email: {e}")

        tc = (cdict.get("taskConfig") or {})
        if tc.get("participateCondition"):
            logger.info(f"[{self.wallet_address}] | Completing participate conditions...")
            campaign = await self.get_campaign_info(campaign_id)
            for i in range(max(VERIFY_TRIES, MAX_TRIES)):
                if i > 0:
                    logger.info(f"[{self.wallet_address}] | wait 30s before retry conditions")
                    await sleep(31)
                    cdict = campaign.to_dict() if hasattr(campaign, "to_dict") else json.loads(
                        json.dumps(campaign, default=lambda o: getattr(o, "__dict__", str(o))))
                pc = tc.get("participateCondition") or {}
                conditions = pc.get("conditions") or []
                credentials = [c.get("cred") for c in conditions]
                conds_as_eligible = [{"eligible": c.get("eligible")} for c in conditions]
                if not conds_as_eligible:
                    logger.success(f'[{self.wallet_address}] | There are no available creds.')
                    break
                group = {"conditions": conds_as_eligible, "credentials": credentials}
                need_retry = await self._complete_condition_group(campaign_id, group)
                await sleep(2)
                if not need_retry:
                    break
            await sleep(5)
            if await self.verify_all_credentials(cdict):
                cdict = campaign.to_dict() if hasattr(campaign, "to_dict") else json.loads(
                    json.dumps(campaign, default=lambda o: getattr(o, "__dict__", str(o))))
            await sleep(5)

        logger.info(f"[{self.wallet_address}] | Completing main credential groups...")
        for i in range(max(VERIFY_TRIES, MAX_TRIES)):
            if i > 0:
                logger.info(f"[{self.wallet_address}] | wait 30s before retry groups")
                await sleep(31)
                campaign = await self.get_campaign_info(campaign_id)
                cdict = campaign.to_dict() if hasattr(campaign, "to_dict") else json.loads(
                    json.dumps(campaign, default=lambda o: getattr(o, "__dict__", str(o))))
            try_again = False
            for group in (cdict.get("credentialGroups") or []):
                conds = group.get("conditions") or []
                if not conds:
                    conds = [{"eligible": (cred.get("eligible", 1))} for cred in (group.get("credentials") or [])]
                group_dict = {"conditions": conds, "credentials": group.get("credentials") or []}
                if await self._complete_condition_group(campaign_id, group_dict):
                    try_again = True
                await sleep(2)
            if not try_again:
                break

        try:
            await self.verify_all_credentials(cdict)
        except Exception:
            pass
        try:
            claimed = await self.claim_campaign(campaign_id, campaign)
        except Exception as e:
            logger.warning(f"[{self.wallet_address}] | claim flow failed: {e}")
            claimed = False
        if claimed:
            logger.success(f"[{self.wallet_address}] | Campaign {campaign_id}: complete+claim done.")
        return claimed

    async def process_campaign(self, campaign_id: str) -> bool:
        return await self.complete_campaign(campaign_id)
