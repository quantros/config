from dataclasses import dataclass
from typing import List, Optional, Dict, Any


@dataclass
class Space:
    id: str
    alias: str
    isAdmin: bool
    name: str
    info: str
    thumbnail: str
    status: str
    links: str
    isVerified: bool
    discordGuildID: str
    followersCount: int
    nftCores: Dict[str, Any]
    isFollowing: bool
    categories: List[str]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Space':
        return Space(
            id=data['id'],
            alias=data['alias'],
            isAdmin=data['isAdmin'],
            name=data['name'],
            info=data['info'],
            thumbnail=data['thumbnail'],
            status=data['status'],
            links=data['links'],
            isVerified=data['isVerified'],
            discordGuildID=data['discordGuildID'],
            followersCount=data['followersCount'],
            nftCores=data['nftCores'],
            isFollowing=data['isFollowing'],
            categories=data['categories']
        )


@dataclass
class Campaign:
    id: str
    thumbnail: str
    isSequencial: bool
    childrenCampaigns: List[Any]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Campaign':
        return Campaign(
            id=data['id'],
            thumbnail=data['thumbnail'],
            isSequencial=data['isSequencial'],
            childrenCampaigns=data['childrenCampaigns']
        )


@dataclass
class Address:
    id: str
    avatar: str

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Address':
        return Address(
            id=data['id'],
            avatar=data['avatar']
        )


@dataclass
class ParticipationRecord:
    address: Address

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'ParticipationRecord':
        return ParticipationRecord(
            address=Address.from_dict(data['address'])
        )


@dataclass
class ParticipantsConnection:
    list: List[ParticipationRecord]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'ParticipantsConnection':
        return ParticipantsConnection(
            list=[ParticipationRecord.from_dict(item) for item in data['list']]
        )


@dataclass
class CampaignParticipant:
    participants: ParticipantsConnection
    participantsCount: int
    bountyWinners: ParticipantsConnection
    bountyWinnersCount: int

    @staticmethod
    def from_dict(data: Optional[Dict[str, Any]]) -> 'CampaignParticipant':
        if data is None:
            return CampaignParticipant(ParticipantsConnection([]), 0, ParticipantsConnection([]), 0)

        return CampaignParticipant(
            participants=ParticipantsConnection.from_dict(data.get('participants', {'list': []})),
            participantsCount=data.get('participantsCount', 0),
            bountyWinners=ParticipantsConnection.from_dict(data.get('bountyWinners', {'list': []})),
            bountyWinnersCount=data.get('bountyWinnersCount', 0)
        )


@dataclass
class Participation:
    id: Optional[str] = None
    status: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Participation":
        if not data:
            return cls()
        return cls(
            id=data.get("id"),
            status=data.get("status"),
        )


@dataclass
class ParticipationConnection:
    list: List[Participation]

    @classmethod
    def from_dict(cls, data: dict) -> "ParticipationConnection":
        items = (data or {}).get("list") or []
        return cls(list=[Participation.from_dict(x) for x in items])


@dataclass
class Gamification:
    id: str
    type: str
    forgeConfig: Optional[Any]
    nfts: List[Any]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Gamification':
        return Gamification(
            id=data['id'],
            type=data['type'],
            forgeConfig=data.get('forgeConfig'),
            nfts=data['nfts']
        )


@dataclass
class CampaignNFTHolderSnapshot:
    holderSnapshotBlock: int

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'CampaignNFTHolderSnapshot':
        return CampaignNFTHolderSnapshot(
            holderSnapshotBlock=data['holderSnapshotBlock']
        )


@dataclass
class LoyaltyPointsRewardInfo:
    points: int

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'LoyaltyPointsRewardInfo':
        return LoyaltyPointsRewardInfo(
            points=data.get('points', 0)
        )


@dataclass
class RewardInfo:
    discordRole: Optional[Any]
    premint: Optional[Any]
    loyaltyPoints: Optional[LoyaltyPointsRewardInfo]
    loyaltyPointsMysteryBox: Optional[Any]

    @staticmethod
    def from_dict(data: Optional[Dict[str, Any]]) -> 'RewardInfo':
        if data is None:
            return RewardInfo(None, None, None, None)

        return RewardInfo(
            discordRole=data.get('discordRole'),
            premint=data.get('premint'),
            loyaltyPoints=LoyaltyPointsRewardInfo.from_dict(data['loyaltyPoints']) if data.get(
                'loyaltyPoints') else None,
            loyaltyPointsMysteryBox=data.get('loyaltyPointsMysteryBox')
        )


@dataclass
class TokenReward:
    userTokenAmount: str
    tokenAddress: str
    depositedTokenAmount: str
    tokenRewardId: Optional[Any]
    tokenDecimal: str
    tokenLogo: str
    tokenSymbol: str

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'TokenReward':
        return TokenReward(
            userTokenAmount=data['userTokenAmount'],
            tokenAddress=data['tokenAddress'],
            depositedTokenAmount=data['depositedTokenAmount'],
            tokenRewardId=data.get('tokenRewardId'),
            tokenDecimal=data['tokenDecimal'],
            tokenLogo=data['tokenLogo'],
            tokenSymbol=data['tokenSymbol']
        )


@dataclass
class WhitelistAddress:
    address: str
    maxCount: int
    usedCount: int
    claimedLoyaltyPoints: int
    currentPeriodClaimedLoyaltyPoints: int
    currentPeriodMaxLoyaltyPoints: int

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'WhitelistAddress':
        return WhitelistAddress(
            address=data['address'],
            maxCount=data['maxCount'],
            usedCount=data['usedCount'],
            claimedLoyaltyPoints=data['claimedLoyaltyPoints'],
            currentPeriodClaimedLoyaltyPoints=data['currentPeriodClaimedLoyaltyPoints'],
            currentPeriodMaxLoyaltyPoints=data['currentPeriodMaxLoyaltyPoints']
        )


@dataclass
class Credential:
    id: str
    name: str
    type: str
    credType: str
    credSource: str
    referenceLink: str
    description: str
    lastUpdate: int
    lastSync: int
    syncStatus: str
    credContractNFTHolder: Optional[Any]
    chain: str
    eligible: int
    subgraph: Optional[Any]
    dimensionConfig: str
    value: Optional[Any]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'Credential':
        return Credential(
            id=data['id'],
            name=data['name'],
            type=data['type'],
            credType=data['credType'],
            credSource=data['credSource'],
            referenceLink=data['referenceLink'],
            description=data['description'],
            lastUpdate=data['lastUpdate'],
            lastSync=data['lastSync'],
            syncStatus=data['syncStatus'],
            credContractNFTHolder=data.get('credContractNFTHolder'),
            chain=data['chain'],
            eligible=data['eligible'],
            subgraph=data.get('subgraph'),
            dimensionConfig=data['dimensionConfig'],
            value=data.get('value')
        )


@dataclass
class CredentialGroup:
    id: str
    description: str
    credentials: List[Credential]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'CredentialGroup':
        return CredentialGroup(
            id=data['id'],
            description=data['description'],
            credentials=[Credential.from_dict(item) for item in data['credentials']]
        )


@dataclass
class CampaignData:
    id: str
    space: Space
    parentCampaign: Campaign
    coHostSpaces: List[Any]
    bannerUrl: str
    thumbnail: str
    rewardName: str
    type: str
    gamification: Gamification
    numberID: int
    chain: str
    spaceStation: Optional[Any]
    name: str
    rewardType: str
    nftHolderSnapshot: CampaignNFTHolderSnapshot
    rewardInfo: RewardInfo
    participants: CampaignParticipant
    inWatchList: bool
    cap: int
    info: str
    useCred: bool
    smartbalancePreCheck: str
    smartbalanceDeposited: bool
    formula: str
    status: str
    seoImage: str
    creator: str
    tags: List[str]
    gasType: str
    isPrivate: bool
    createdAt: str
    requirementInfo: str
    description: str
    enableWhitelist: bool
    startTime: int
    endTime: Optional[Any]
    requireEmail: bool
    requireUsername: bool
    blacklistCountryCodes: str
    whitelistRegions: str
    distributionType: str
    claimEndTime: Optional[Any]
    loyaltyPoints: int
    tokenRewardContract: Optional[Any]
    tokenReward: TokenReward
    whitelistInfo: WhitelistAddress
    whitelistSubgraph: Optional[Any]
    creds: List[Any]
    credentialGroups: List[CredentialGroup]
    taskConfig: Dict[str, Any]
    referralCode: Optional[Any]
    recurringType: str
    latestRecurringTime: int
    nftTemplates: List[Any]
    userParticipants: ParticipationConnection
    isBookmarked: bool
    claimedLoyaltyPoints: int
    isSequencial: bool
    numNFTMinted: int
    childrenCampaigns: Optional[List]

    @staticmethod
    def from_dict(data: Dict[str, Any]) -> 'CampaignData':
        return CampaignData(
            id=data['id'],
            space=Space.from_dict(data['space']),
            parentCampaign=Campaign.from_dict(data['parentCampaign']),
            coHostSpaces=data['coHostSpaces'],
            bannerUrl=data['bannerUrl'],
            thumbnail=data['thumbnail'],
            rewardName=data['rewardName'],
            type=data['type'],
            gamification=Gamification.from_dict(data['gamification']),
            numberID=data['numberID'],
            chain=data['chain'],
            spaceStation=data.get('spaceStation'),
            name=data['name'],
            rewardType=data['rewardType'],
            nftHolderSnapshot=CampaignNFTHolderSnapshot.from_dict(data['nftHolderSnapshot']),
            rewardInfo=RewardInfo.from_dict(data['rewardInfo']),
            participants=CampaignParticipant.from_dict(data['participants']),
            inWatchList=data['inWatchList'],
            cap=data['cap'],
            info=data['info'],
            useCred=data['useCred'],
            smartbalancePreCheck=data['smartbalancePreCheck'],
            smartbalanceDeposited=data['smartbalanceDeposited'],
            formula=data['formula'],
            status=data['status'],
            seoImage=data['seoImage'],
            creator=data['creator'],
            tags=data['tags'],
            gasType=data['gasType'],
            isPrivate=data['isPrivate'],
            createdAt=data['createdAt'],
            requirementInfo=data['requirementInfo'],
            description=data['description'],
            enableWhitelist=data['enableWhitelist'],
            startTime=data['startTime'],
            endTime=data.get('endTime'),
            requireEmail=data['requireEmail'],
            requireUsername=data['requireUsername'],
            blacklistCountryCodes=data['blacklistCountryCodes'],
            whitelistRegions=data['whitelistRegions'],
            distributionType=data['distributionType'],
            claimEndTime=data.get('claimEndTime'),
            loyaltyPoints=data['loyaltyPoints'],
            tokenRewardContract=data.get('tokenRewardContract'),
            tokenReward=TokenReward.from_dict(data['tokenReward']),
            whitelistInfo=WhitelistAddress.from_dict(data['whitelistInfo']),
            whitelistSubgraph=data.get('whitelistSubgraph'),
            creds=data['creds'],
            credentialGroups=[CredentialGroup.from_dict(item) for item in data['credentialGroups']],
            taskConfig=data.get('taskConfig', {}),
            referralCode=data.get('referralCode'),
            recurringType=data['recurringType'],
            latestRecurringTime=data['latestRecurringTime'],
            nftTemplates=data['nftTemplates'],
            userParticipants=ParticipationConnection.from_dict(data.get('userParticipants', {'list': []})),
            isBookmarked=data['isBookmarked'],
            claimedLoyaltyPoints=data['claimedLoyaltyPoints'],
            isSequencial=data['isSequencial'],
            numNFTMinted=data['numNFTMinted'],
            childrenCampaigns=data.get('childrenCampaigns') or [],
        )
