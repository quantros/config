from dataclasses import dataclass


@dataclass
class ERC20:
    abi: str = open('./assets/abi/erc20.json', 'r').read()


@dataclass
class WrapData:
    abi: str = open('./assets/abi/eth.json', 'r').read()


@dataclass
class TestnetBridgeData:
    address: str = '0xfcA99F4B5186D4bfBDbd2C542dcA2ecA4906BA45'
    address_op: str = '0x8352C746839699B1fc631fddc0C3a00d4AC71A17'
    abi: str = open('./assets/abi/testnet_bridge.json', 'r').read()


@dataclass
class SuperBridgeData:
    address: str = "0x136d377D3F820F8D6e3d5Cb16f51e7E5037BD876"
    abi: str = open('./assets/abi/super_bridge.json', 'r').read()


@dataclass
class DomainData:
    address: str = '0x0000000000000068F116a894984e2DB1123eB395'
    claim_address: str = '0xb1508299A01c02aC3B70c7A8B0B07105aaB29E99'
    abi: str = open('./assets/abi/domain.json', 'r').read()


@dataclass
class GalxeData:
    abi: str = open('./assets/abi/galxe.json', 'r').read()
