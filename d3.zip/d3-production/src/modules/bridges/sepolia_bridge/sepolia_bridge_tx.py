from typing import Optional, Callable, Tuple

from loguru import logger
from web3 import AsyncWeb3
from web3.contract import AsyncContract
from web3.types import TxParams

from src.models.bridge import BridgeConfig


async def create_sepolia_bridge_tx(
        self,
        contract: Optional[AsyncContract],
        bridge_config: BridgeConfig,
        amount: int
) -> Tuple[TxParams, None]:
    amount_out = await get_amount_out(amount, self.make_request, self.web3)
    fee = await estimate_send_fee(self.make_request)
    if fee > 20000000000000 or not fee:
        logger.error(f'[{self.wallet_address}] | Failed to get fee.')
        return None
    last_block = await self.web3.eth.get_block('latest')
    max_priority_fee_per_gas = await self.web3.eth.max_priority_fee
    base_fee = int(last_block['baseFeePerGas'] * 1.15)
    max_fee_per_gas = base_fee + max_priority_fee_per_gas
    tx = await contract.functions.swapAndBridge(
        amount,
        amount_out,
        161,
        self.wallet_address,
        self.wallet_address,
        self.web3.to_checksum_address('0x0000000000000000000000000000000000000000'),
        b''
    ).build_transaction({
        'from': self.wallet_address,
        'value': amount + int(fee * 1.1),
        'nonce': await self.web3.eth.get_transaction_count(self.wallet_address),
        "maxPriorityFeePerGas": max_priority_fee_per_gas,
        "maxFeePerGas": max_fee_per_gas,
    })

    return tx, None


def read_uint256_word(hexdata: str, word_index: int = 0) -> int:
    h = hexdata[2:] if hexdata.startswith("0x") else hexdata
    if len(h) < (word_index + 1) * 64 or len(h) % 64 != 0:
        raise ValueError("Failed to get fee")
    start = word_index * 64
    return int(h[start:start + 64], 16)


async def estimate_send_fee(request_function: Callable):
    json_data = [
        {
            'method': 'eth_call',
            'params': [
                {
                    'to': '0xe71bdfe1df69284f00ee185cf0d95d0c7680c0d4',
                    'data': '0x2a205e3d00000000000000000000000000000000000000000000000000000000000000a100000000000000000000000000000000000000000000000000000000000000a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000e0000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000',
                },
                'latest',
            ],
            'id': 43,
            'jsonrpc': '2.0',
        },
    ]
    while True:
        try:
            response_json, status = await request_function(
                method='POST',
                url='https://arb1.arbitrum.io/rpc',
                json=json_data
            )
            result = response_json[0]['result']
            return read_uint256_word(result, 0)
        except Exception:
            return None


async def get_amount_out(amount_in: int, request_function: Callable, web3: AsyncWeb3) -> int:
    amount_in_hex = web3.to_hex(amount_in)[2:]
    if len(amount_in_hex) < 13:
        amount_in_hex = f"{'0' * (13 - len(amount_in_hex))}{amount_in_hex}"
    elif len(amount_in_hex) > 13:
        amount_in_hex = amount_in_hex[:13]

    json_data = [
        {
            "method": "eth_call",
            "params": [
                {
                    "to": "0xb27308f9f90d607463bb33ea1bebb41c27ce5ab6",
                    "data": f"0xf7729d4300000000000000000000000082af49447d8a07e3bd95bd0d56f35241523fbab1000000000000000000000000e71bdfe1df69284f00ee185cf0d95d0c7680c0d40000000000000000000000000000000000000000000000000000000000000bb8000000000000000000000000000000000000000000000000000{amount_in_hex}0000000000000000000000000000000000000000000000000000000000000000",
                },
                "latest",
            ],
            "id": 82,
            "jsonrpc": "2.0",
        },
    ]

    while True:
        try:
            response_json, status = await request_function(
                method='POST',
                url='https://arb1.arbitrum.io/rpc',
                json=json_data
            )

            if not isinstance(response_json, list) or not response_json:
                logger.error(f"Invalid response structure: {response_json}")
                return 0

            response_data = response_json[0]

            if "result" not in response_data:
                logger.error(f"Missing 'result' field: {response_data}")
                return 0

            raw_hex = response_data["result"]

            if not raw_hex or raw_hex == "0x":
                logger.error("Response result is empty or zero.")
                return 0

            amount_out_hex = int(raw_hex, 16)
            amount_out = int(amount_out_hex * 0.95)
            return amount_out

        except (TypeError, IndexError, ValueError) as ex:
            logger.error(f"Error in get_amount_out: {ex}")
            return 0
