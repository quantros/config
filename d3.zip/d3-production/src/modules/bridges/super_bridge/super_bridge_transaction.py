from typing import Optional

import async_tls_client
from web3.contract import AsyncContract

from src.models.bridge import BridgeConfig


async def create_super_bridge_tx(
        self,
        contract: Optional[AsyncContract],
        bridge_config: BridgeConfig,
        amount: int
):
    # headers = {
    #     'accept': 'application/json, text/plain, */*',
    #     'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    #     'content-type': 'application/json',
    #     'origin': 'https://testnets.superbridge.app',
    #     'priority': 'u=1, i',
    #     'referer': 'https://testnets.superbridge.app',
    #     'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
    #     'sec-ch-ua-mobile': '?0',
    #     'sec-ch-ua-platform': '"Windows"',
    #     'sec-fetch-dest': 'empty',
    #     'sec-fetch-mode': 'cors',
    #     'sec-fetch-site': 'cross-site',
    #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    # }
    #
    # json_data = {
    #     'id': {
    #         'tokensId': '50275c3f-a01a-4045-a2be-232c376e1f8d',
    #     },
    #     'amount': str(amount),
    #     'fromChainId': str(bridge_config.from_chain.chain_id),
    #     'toChainId': str(bridge_config.to_chain.chain_id),
    #     'fromTokenAddress': '0x0000000000000000000000000000000000000000',
    #     'graffiti': 'superbridge',
    #     'recipient': self.wallet_address,
    #     'sender': self.wallet_address,
    #     'slippage': 1,
    #     'forceViaL1': False,
    #     'multichainTokens': [],
    # }
    #
    # session = async_tls_client.AsyncSession(
    #     client_identifier='chrome_133',
    #     random_tls_extension_order=True,
    # )
    # session.proxies.update({
    #     'http': self.proxy.proxy_url if self.proxy else None,
    #     'https': self.proxy.proxy_url if self.proxy else None
    # })
    #
    # response = await session.execute_request(
    #     method="POST",
    #     url="https://api.superbridge.app/api/v3/bridge/routes",
    #     headers=headers,
    #     json=json_data
    # )
    # if response.status_code == 200:
    # transaction = response.json()['results'][0]['result']['initiatingTransaction']
    # to = transaction['to']

    last_block = await self.web3.eth.get_block('latest')
    max_priority_fee_per_gas = await self.web3.eth.max_priority_fee
    base_fee = int(last_block['baseFeePerGas'] * 1.15)
    max_fee_per_gas = base_fee + max_priority_fee_per_gas

    tx = await contract.functions.bridgeETHTo(
        self.wallet_address,
        200000,
        b'0x7375706572627269646765'
    ).build_transaction({
        'from': self.wallet_address,
        'value': amount,
        'nonce': await self.web3.eth.get_transaction_count(self.wallet_address),
        "maxPriorityFeePerGas": max_priority_fee_per_gas,
        "maxFeePerGas": max_fee_per_gas,
    })

    return tx, None
