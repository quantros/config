# Версия софта от 00:37 22.08.2025
LICENSE_KEY = ''  # Брать ключ в боте, по кнопке "Софты"

MOBILE_PROXY = False  # True - мобильные proxy/False - обычные proxy
ROTATE_IP = False  # Настройка только для мобильных proxy

DOMA_TESTNET_RPC = 'https://rpc-testnet.doma.xyz'

TG_BOT_TOKEN = ''  # str ('2282282282:NTcwMzA0Mjg1NC-vVxT3nb-jr-db976M435xmT_0R7tnaQSVBM6Xdjry')
TG_USER_ID = 123  # int (22822822) or None
CHERRY_SOLVER_API_KEY = ''  # @CherryCaptcha_bot

SHUFFLE_WALLETS = False
PAUSE_BETWEEN_WALLETS = [1, 1]
PAUSE_BETWEEN_MODULES = [1, 2]
MAX_PARALLEL_ACCOUNTS = 20

RETRIES = 3  # Сколько раз повторять 'зафейленное' действие
PAUSE_BETWEEN_RETRIES = 15  # Пауза между повторами

TESTNET_BRIDGE = False  # ARB/OP -> SEPOLIA (Настройки в TestnetBridgeConfig)
SUPER_BRIDGE = False  # SEPOLIA -> DOMA (Настройка в SuperBridgeSettings)

COMPLETE_D3_PROFILE = False
BUY_DOMAIN = False  # Настройка в BuyDomainSettings
LIST_DOMAIN = False  # Листинг домена. Настройка в DomainListingSettings
OFFER_DOMAIN = False  # Оффер на рандомный домен. Настройка в DomainOfferSettings

COMPLETE_GALXE = False  # Настройка в GalxeSettings


class TestnetBridgeConfig:
    from_chain = ['OP', 'ARB']  # ARB/OP
    to_chain = 'SEPOLIA'  # не меняем
    amount = [0.001, 0.0012]
    use_percentage = False  # не меняем, если не хотим чтобы забриджилось много эфира в тестовую сеть. Оставляем False.
    bridge_percentage = [0.1, 0.2]
    min_sepolia_eth_balance = 5  # минимальный баланс ETH в сети Sepolia. Если больше, то бридж сделан не будет.
    min_doma_eth_balance = 0.5  # Если баланс ETH в сети DOMA выше, то бриджа не будет


class SuperBridgeSettings:
    from_chain = 'SEPOLIA'
    to_chain = 'DOMA'

    amount = [0.001, 0.002]  # Кол-во ETH [от, до]
    use_percentage = True  # Использовать ли процент от баланса вместо amount
    bridge_percentage = [0.5, 0.5]  # Процент от баланса. 0.1 - это 10%, 0.27 - это 27% и т.д.
    min_eth_balance = 0.5  # Минимальный баланс в сети to_chain. Если выше, то бридж сделан не будет.


class BuyDomainSettings:
    """
    mode = 0 - стандартная покупка
    mode = 1 - покупка домена длинной до 5 символов включительно + существующее слово
    mode = 2 - покупка домена длинной до 4 символов включительно + тематика finance/fintech/wealth
    mode = 3 - покупка домена длинной до 6 символов включительно + заканчивается на ly/io/fy
    mode = 4 - покупка домена с названием товара
    mode = 5 - покупка домена с суффиксом hub, stack или works
    mode = 6 - покупка домена, в составе которого встречается слово free, deal, fast или hot
    """

    mode = [0, 1, 3]
    max_percentage_of_balance = [0.1, 0.2]  # Максимально доступная цена в процентах от баланса.


class DomainListingSettings:
    price = [100, 300]  # Цена домена в ETH


class DomainOfferSettings:
    percentage_to_wrap = [0.1, 0.3]  # ETH -> WETH
    percentage_to_offer = [0.01, 0.03]


class GalxeSettings:
    campaign_ids = ['GCziSt6zBd']

# GCgTJtfT8o - 1 неделя
# GCwVkt6uNW - 2 неделя
# GCLq8t6Z42 - 3 неделя
# GCziSt6zBd - 4 неделя
